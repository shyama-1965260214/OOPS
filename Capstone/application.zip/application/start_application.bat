
@echo off
title CYBERSHIELD STARTUP
cd /d "%~dp0"

echo ========================================
echo       CYBERSHIELD STARTING
echo ========================================

echo Starting Backend...
start "CyberShield Backend" cmd /k "cd /d ""%~dp0"" && call run_backend.bat"

timeout /t 3 /nobreak >nul

echo Starting Frontend...
start "CyberShield Frontend" cmd /k "cd /d ""%~dp0"" && call run_frontend.bat"

timeout /t 5 /nobreak >nul

start "" "http://localhost:5173/"

echo CyberShield startup completed.
exit
