#include "AlertManager.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <algorithm>

AlertManager::AlertManager() : persistencePath("CyberShield/data/alerts_store.json"), nextAlertNumber(1) {}

AlertManager::AlertManager(const std::string& storePath) : persistencePath(storePath), nextAlertNumber(1) {
    loadFromStore(storePath);
}

std::string AlertManager::getCurrentDateTimeString() const {
    time_t now = time(nullptr);
    struct tm tmBuf;
#if defined(_WIN32)
    gmtime_s(&tmBuf, &now);
#else
    gmtime_r(&now, &tmBuf);
#endif
    char buf[64];
    std::snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d",
                  tmBuf.tm_year + 1900, tmBuf.tm_mon + 1, tmBuf.tm_mday,
                  tmBuf.tm_hour, tmBuf.tm_min, tmBuf.tm_sec);
    return std::string(buf);
}

std::string AlertManager::generateUniqueAlertId() {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "ALT-%04d", nextAlertNumber++);
    return std::string(buf);
}

void AlertManager::ingestThreats(const std::vector<DetectedThreat>& threats) {
    if (!persistencePath.empty()) {
        loadFromStore(persistencePath);
    }

    std::map<std::string, size_t> existingFingerprints;
    for (size_t i = 0; i < alerts.size(); ++i) {
        existingFingerprints[alerts[i].getFingerprint()] = i;
    }

    std::string nowStr = getCurrentDateTimeString();
    int newAlertCount = 0;

    for (const auto& threat : threats) {
        std::string fp = threat.attackCategory + "|" + threat.sourceIp + "|" + threat.timestamp;

        if (existingFingerprints.find(fp) != existingFingerprints.end()) {
            // Already present: preserve the analyst's status (Investigating, Resolved, False Positive)
            size_t idx = existingFingerprints[fp];
            alerts[idx].suspiciousEventCount = threat.suspiciousEventCount;
            alerts[idx].explanation = threat.explanation;
            alerts[idx].updatedAt = nowStr;
        } else {
            // Create a brand new security alert
            SecurityAlert alert;
            alert.alertId = generateUniqueAlertId();
            alert.attackCategory = threat.attackCategory;
            alert.sourceIp = threat.sourceIp;
            alert.timestamp = threat.timestamp;
            alert.epochSeconds = threat.epochSeconds;
            alert.suspiciousEventCount = threat.suspiciousEventCount;
            alert.severity = threat.severity;
            alert.explanation = threat.explanation;
            alert.ruleTriggered = threat.ruleTriggered;
            alert.status = "New";
            alert.createdAt = nowStr;
            alert.updatedAt = nowStr;

            existingFingerprints[fp] = alerts.size();
            alerts.push_back(alert);
            newAlertCount++;
        }
    }

    std::cout << "[AlertManager] Ingestion complete. Existing: " 
              << (alerts.size() - newAlertCount) 
              << " | New: " << newAlertCount 
              << " | Total Stored: " << alerts.size() << std::endl;

    if (!persistencePath.empty()) {
        saveToStore(persistencePath);
    }
}

bool AlertManager::updateStatus(const std::string& alertId, const std::string& newStatus) {
    // Validate status
    if (newStatus != "New" && newStatus != "Investigating" && 
        newStatus != "Resolved" && newStatus != "False Positive") {
        std::cerr << "[AlertManager ERROR] Invalid status requested: " << newStatus << std::endl;
        return false;
    }

    for (auto& alert : alerts) {
        if (alert.alertId == alertId) {
            alert.status = newStatus;
            alert.updatedAt = getCurrentDateTimeString();
            std::cout << "[AlertManager] Alert " << alertId << " status updated to: " << newStatus << std::endl;
            if (!persistencePath.empty()) {
                saveToStore(persistencePath);
            }
            return true;
        }
    }

    std::cerr << "[AlertManager ERROR] Alert ID not found: " << alertId << std::endl;
    return false;
}

std::vector<SecurityAlert> AlertManager::filterAlerts(const std::string& categoryFilter,
                                                     const std::string& severityFilter,
                                                     const std::string& statusFilter,
                                                     const std::string& searchKeyword) const {
    std::vector<SecurityAlert> result;
    std::string kwLower = searchKeyword;
    for (char &c : kwLower) c = std::tolower(static_cast<unsigned char>(c));

    for (const auto& a : alerts) {
        if (!categoryFilter.empty() && a.attackCategory != categoryFilter) continue;
        if (!severityFilter.empty() && a.severity != severityFilter) continue;
        if (!statusFilter.empty() && a.status != statusFilter) continue;

        if (!kwLower.empty()) {
            std::string text = a.alertId + " " + a.sourceIp + " " + a.attackCategory + " " + a.explanation;
            for (char &c : text) c = std::tolower(static_cast<unsigned char>(c));
            if (text.find(kwLower) == std::string::npos) continue;
        }

        result.push_back(a);
    }
    return result;
}

ReportSummary AlertManager::getReportSummary() const {
    ReportSummary summary;
    summary.totalAlerts = static_cast<int>(alerts.size());

    for (const auto& a : alerts) {
        if (a.severity == "HIGH") summary.highSeverityCount++;
        else if (a.severity == "MEDIUM") summary.mediumSeverityCount++;
        else summary.lowSeverityCount++;

        if (a.status == "New") summary.newCount++;
        else if (a.status == "Investigating") summary.investigatingCount++;
        else if (a.status == "Resolved") summary.resolvedCount++;
        else if (a.status == "False Positive") summary.falsePositiveCount++;

        summary.categoryDistribution[a.attackCategory]++;
        summary.suspiciousIpCounts[a.sourceIp]++;
    }

    return summary;
}

static std::string escapeJson(const std::string& s) {
    std::string res;
    for (char c : s) {
        if (c == '\"') res += "\\\"";
        else if (c == '\\') res += "\\\\";
        else if (c == '\n') res += "\\n";
        else if (c == '\r') res += "\\r";
        else if (c == '\t') res += "\\t";
        else res += c;
    }
    return res;
}

bool AlertManager::saveToStore(const std::string& storePath) const {
    std::ofstream file(storePath);
    if (!file.is_open()) {
        std::cerr << "[AlertManager ERROR] Failed to write persistent store: " << storePath << std::endl;
        return false;
    }

    file << "[\n";
    for (size_t i = 0; i < alerts.size(); ++i) {
        const auto& a = alerts[i];
        file << "  {\n";
        file << "    \"alertId\": \"" << escapeJson(a.alertId) << "\",\n";
        file << "    \"attackCategory\": \"" << escapeJson(a.attackCategory) << "\",\n";
        file << "    \"sourceIp\": \"" << escapeJson(a.sourceIp) << "\",\n";
        file << "    \"timestamp\": \"" << escapeJson(a.timestamp) << "\",\n";
        file << "    \"epochSeconds\": " << a.epochSeconds << ",\n";
        file << "    \"suspiciousEventCount\": " << a.suspiciousEventCount << ",\n";
        file << "    \"severity\": \"" << escapeJson(a.severity) << "\",\n";
        file << "    \"explanation\": \"" << escapeJson(a.explanation) << "\",\n";
        file << "    \"ruleTriggered\": \"" << escapeJson(a.ruleTriggered) << "\",\n";
        file << "    \"status\": \"" << escapeJson(a.status) << "\",\n";
        file << "    \"createdAt\": \"" << escapeJson(a.createdAt) << "\",\n";
        file << "    \"updatedAt\": \"" << escapeJson(a.updatedAt) << "\"\n";
        file << "  }" << (i + 1 < alerts.size() ? "," : "") << "\n";
    }
    file << "]\n";

    file.close();
    return true;
}

bool AlertManager::loadFromStore(const std::string& storePath) {
    std::ifstream file(storePath);
    if (!file.is_open()) {
        // File does not exist yet (normal on fresh startup)
        return false;
    }

    alerts.clear();
    std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();

    // Parse array of objects in JSON
    size_t pos = 0;
    int maxIdNum = 0;

    while ((pos = content.find('{', pos)) != std::string::npos) {
        size_t endObj = content.find('}', pos);
        if (endObj == std::string::npos) break;

        std::string objStr = content.substr(pos + 1, endObj - pos - 1);
        pos = endObj + 1;

        SecurityAlert alert;
        std::istringstream iss(objStr);
        std::string line;

        while (std::getline(iss, line)) {
            size_t colon = line.find(':');
            if (colon == std::string::npos) continue;

            std::string key = LogUtils::trim(line.substr(0, colon));
            std::string val = LogUtils::trim(line.substr(colon + 1));

            if (!key.empty() && key.front() == '\"') key = key.substr(1);
            if (!key.empty() && key.back() == '\"') key.pop_back();

            while (!val.empty() && (val.back() == ',' || val.back() == '\"' || val.back() == '\r')) val.pop_back();
            if (!val.empty() && val.front() == '\"') val = val.substr(1);

            if (key == "alertId") alert.alertId = val;
            else if (key == "attackCategory") alert.attackCategory = val;
            else if (key == "sourceIp") alert.sourceIp = val;
            else if (key == "timestamp") alert.timestamp = val;
            else if (key == "epochSeconds") {
                try { alert.epochSeconds = std::stoll(val); } catch (...) {}
            }
            else if (key == "suspiciousEventCount") {
                try { alert.suspiciousEventCount = std::stoi(val); } catch (...) {}
            }
            else if (key == "severity") alert.severity = val;
            else if (key == "explanation") alert.explanation = val;
            else if (key == "ruleTriggered") alert.ruleTriggered = val;
            else if (key == "status") alert.status = val;
            else if (key == "createdAt") alert.createdAt = val;
            else if (key == "updatedAt") alert.updatedAt = val;
        }

        if (!alert.alertId.empty()) {
            alerts.push_back(alert);
            // Track max alert number to ensure unique sequence
            if (alert.alertId.rfind("ALT-", 0) == 0) {
                try {
                    int num = std::stoi(alert.alertId.substr(4));
                    if (num > maxIdNum) maxIdNum = num;
                } catch (...) {}
            }
        }
    }

    nextAlertNumber = maxIdNum + 1;
    return true;
}

static std::string escapeCsv(const std::string& s) {
    std::string res = "\"";
    for (char c : s) {
        if (c == '\"') res += "\"\"";
        else res += c;
    }
    res += "\"";
    return res;
}

bool AlertManager::generateCsvReport(const std::string& outputPath, const AnalysisMetrics* metrics) const {
    std::ofstream out(outputPath);
    if (!out.is_open()) {
        std::cerr << "[AlertManager ERROR] Unable to open report file for writing: " << outputPath << std::endl;
        return false;
    }

    ReportSummary summary = getReportSummary();

    // Section 1: Report Metadata & Executive Summary
    out << "CYBERSHIELD SECURITY INCIDENT & ANALYSIS REPORT\n";
    out << "Generated At," << escapeCsv(getCurrentDateTimeString()) << "\n";
    if (metrics) {
        out << "Total Logs Analyzed," << metrics->totalEvents << "\n";
        out << "Successful Logins," << metrics->successfulLogins << "\n";
        out << "Failed Logins," << metrics->failedLogins << "\n";
        out << "Unique Monitored IPs," << metrics->uniqueIpCount << "\n";
    }
    out << "Total Threats Detected," << summary.totalAlerts << "\n";
    out << "High Severity Incidents," << summary.highSeverityCount << "\n";
    out << "Medium Severity Incidents," << summary.mediumSeverityCount << "\n";
    out << "Resolved Incidents," << summary.resolvedCount << "\n";
    out << "Active / Unresolved Incidents," << (summary.totalAlerts - summary.resolvedCount - summary.falsePositiveCount) << "\n";
    out << "False Positives," << summary.falsePositiveCount << "\n";
    out << "\n";

    // Section 2: Attack Category Breakdown
    out << "--- ATTACK CATEGORY DISTRIBUTION ---\n";
    out << "Attack Category,Incident Count\n";
    for (const auto& pair : summary.categoryDistribution) {
        out << escapeCsv(pair.first) << "," << pair.second << "\n";
    }
    out << "\n";

    // Section 3: Suspicious IP Summary
    out << "--- SUSPICIOUS SOURCE IP SUMMARY ---\n";
    out << "Source IP,Threat Count\n";
    for (const auto& pair : summary.suspiciousIpCounts) {
        out << escapeCsv(pair.first) << "," << pair.second << "\n";
    }
    out << "\n";

    // Section 4: Detailed Security Incidents
    out << "--- DETAILED SECURITY INCIDENT LOGS ---\n";
    out << "Alert ID,Attack Category,Source IP,Timestamp,Suspicious Events,Severity,Status,Rule Triggered,Explanation,Created At,Updated At\n";
    for (const auto& a : alerts) {
        out << escapeCsv(a.alertId) << ","
            << escapeCsv(a.attackCategory) << ","
            << escapeCsv(a.sourceIp) << ","
            << escapeCsv(a.timestamp) << ","
            << a.suspiciousEventCount << ","
            << escapeCsv(a.severity) << ","
            << escapeCsv(a.status) << ","
            << escapeCsv(a.ruleTriggered) << ","
            << escapeCsv(a.explanation) << ","
            << escapeCsv(a.createdAt) << ","
            << escapeCsv(a.updatedAt) << "\n";
    }

    out.close();
    std::cout << "[AlertManager] Successfully generated CSV report at: " << outputPath << std::endl;
    return true;
}
