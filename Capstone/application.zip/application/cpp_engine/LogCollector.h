#ifndef LOGCOLLECTOR_H
#define LOGCOLLECTOR_H

#include "LogRecord.h"
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <memory>

/**
 * @struct ValidationError
 * @brief Details of an invalid or malformed log record.
 */
struct ValidationError {
    int lineNumber;
    std::string rawLine;
    std::string reason;
};

/**
 * @class LogCollector
 * @brief Module 1: Collects, parses, validates, and stores log records from files.
 */
class LogCollector {
public:
    LogCollector();
    ~LogCollector() = default;

    /**
     * @brief Load and parse log entries from a file (CSV or TXT).
     * @param filePath Path to the input file.
     * @return True if file was successfully opened and parsed, false otherwise.
     */
    bool loadFromFile(const std::string& filePath);

    /**
     * @brief Clear all stored records and error logs.
     */
    void clear();

    // Getters
    const std::vector<LogRecord>& getValidRecords() const { return validRecords; }
    const std::vector<ValidationError>& getValidationErrors() const { return validationErrors; }
    size_t getValidCount() const { return validRecords.size(); }
    size_t getInvalidCount() const { return validationErrors.size(); }
    size_t getTotalLinesRead() const { return totalLinesRead; }
    const std::string& getLoadedFilePath() const { return currentFilePath; }

private:
    std::vector<LogRecord> validRecords;
    std::vector<ValidationError> validationErrors;
    size_t totalLinesRead;
    std::string currentFilePath;

    /**
     * @brief Internal helper to validate and construct a LogRecord from raw tokens.
     */
    bool parseAndValidateLine(int lineNum, const std::string& line, LogRecord& outRecord, std::string& outError);
};

#endif // LOGCOLLECTOR_H
