cmake_minimum_required(VERSION 3.15)
project(CyberShield VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Engine sources
set(ENGINE_SOURCES
    LogRecord.h
    LogCollector.h
    LogCollector.cpp
    LogAnalyzer.h
    LogAnalyzer.cpp
    ThreatDetector.h
    ThreatDetector.cpp
    AlertManager.h
    AlertManager.cpp
)

# Core CyberShield CLI Executable
add_executable(cybershield_engine
    main.cpp
    ../tests/detection_tests.cpp
    ${ENGINE_SOURCES}
)
target_compile_definitions(cybershield_engine PRIVATE EXCLUDE_STANDALONE_MAIN)

# Standalone Tests Executable
add_executable(detection_tests
    ../tests/detection_tests.cpp
    ${ENGINE_SOURCES}
)
