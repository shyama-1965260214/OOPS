#ifndef LOGANALYZER_H
#define LOGANALYZER_H

#include "LogRecord.h"
#include <vector>
#include <string>
#include <map>
#include <unordered_map>
#include <algorithm>

/**
 * @struct IpActivity
 * @brief Summary of activity metrics for a specific source IP.
 */
struct IpActivity {
    std::string ip;
    int totalEvents = 0;
    int failedLogins = 0;
    int successfulLogins = 0;
    int uniquePortsProbed = 0;
    int deniedAccessCount = 0;
};

/**
 * @struct TimelineBucket
 * @brief Aggregated event count within a specific time interval.
 */
struct TimelineBucket {
    std::string timeLabel;  // e.g. "09:00", "09:10"
    int64_t epochStart = 0;
    int eventCount = 0;
};

/**
 * @struct AnalysisMetrics
 * @brief Comprehensive statistical results from log analysis.
 */
struct AnalysisMetrics {
    int totalEvents = 0;
    int successfulLogins = 0;
    int failedLogins = 0;
    int otherEvents = 0;
    int uniqueIpCount = 0;
    std::map<std::string, int> eventDistribution;
    std::vector<IpActivity> mostActiveIps;
    std::map<std::string, int> repeatedLoginFailures; // IP -> failed count
    std::vector<TimelineBucket> activityTimeline;
};

/**
 * @class LogAnalyzer
 * @brief Module 2: Analyzes collected logs, aggregates metrics, and generates activity profiles.
 */
class LogAnalyzer {
public:
    LogAnalyzer();
    ~LogAnalyzer() = default;

    /**
     * @brief Run complete analysis on a set of log records.
     * @param records Vector of validated LogRecord objects.
     */
    void analyze(const std::vector<LogRecord>& records);

    /**
     * @brief Filter records by criteria.
     */
    std::vector<LogRecord> filterRecords(const std::vector<LogRecord>& sourceRecords,
                                         const std::string& ipFilter,
                                         const std::string& eventFilter,
                                         int64_t startEpoch = 0,
                                         int64_t endEpoch = 0) const;

    // Getters
    const AnalysisMetrics& getMetrics() const { return metrics; }
    const std::map<std::string, std::vector<LogRecord>>& getIpGroupedRecords() const { return ipGroups; }

private:
    AnalysisMetrics metrics;
    std::map<std::string, std::vector<LogRecord>> ipGroups;

    void groupRecordsByIp(const std::vector<LogRecord>& records);
    void computeLoginCounts(const std::vector<LogRecord>& records);
    void computeEventDistribution(const std::vector<LogRecord>& records);
    void computeActiveIps();
    void computeTimeline(const std::vector<LogRecord>& records);
};

#endif // LOGANALYZER_H
