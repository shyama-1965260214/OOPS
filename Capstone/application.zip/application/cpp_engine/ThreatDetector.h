#ifndef THREATDETECTOR_H
#define THREATDETECTOR_H

#include "LogRecord.h"
#include <vector>
#include <string>
#include <map>
#include <set>
#include <memory>

/**
 * @struct DetectionConfig
 * @brief Configurable detection thresholds and time window durations (in seconds).
 */
struct DetectionConfig {
    // Attack 1: Brute-Force Login
    int bruteForceThreshold = 5;          // Minimum failed logins to trigger alert
    int bruteForceWindowSec = 300;        // Time window in seconds (5 minutes)
    std::string bruteForceSeverity = "HIGH";

    // Attack 2: Port Scanning
    int portScanThreshold = 10;           // Minimum distinct destination ports to trigger alert
    int portScanWindowSec = 300;          // Time window in seconds (5 minutes)
    std::string portScanSeverity = "MEDIUM";

    // Attack 3: Unauthorized Resource Access
    int unauthorizedThreshold = 5;        // Minimum denied/restricted attempts
    int unauthorizedWindowSec = 300;      // Time window in seconds (5 minutes)
    std::string unauthorizedSeverity = "HIGH";

    // Attack 4: Request Flooding
    int requestFloodThreshold = 50;       // Minimum total requests
    int requestFloodWindowSec = 60;       // Time window in seconds (1 minute)
    std::string requestFloodSeverity = "HIGH";
};

/**
 * @struct DetectedThreat
 * @brief Represents an identified potential cyberattack threat event.
 */
struct DetectedThreat {
    std::string threatId;
    std::string attackCategory;       // e.g. "Brute-Force Login", "Port Scanning"
    std::string sourceIp;             // Attacking IP
    std::string timestamp;            // Detection timestamp (first or peak trigger time)
    int64_t epochSeconds = 0;         // Epoch timestamp
    int suspiciousEventCount = 0;     // Number of triggering events in the window
    std::string severity;             // HIGH, MEDIUM, LOW
    std::string explanation;          // Human-readable incident breakdown
    std::string ruleTriggered;        // Specific detection rule code
    std::string timeWindowDescription;// e.g. "5 events within 300s window"
};

/**
 * @class ThreatDetector
 * @brief Module 3: Rule-based cyberattack detection engine utilizing sliding time windows.
 */
class ThreatDetector {
public:
    ThreatDetector();
    explicit ThreatDetector(const DetectionConfig& cfg);
    ~ThreatDetector() = default;

    /**
     * @brief Configure detection engine parameters.
     */
    void setConfig(const DetectionConfig& cfg) { config = cfg; }
    const DetectionConfig& getConfig() const { return config; }

    /**
     * @brief Execute threat detection across all validated records.
     * @param records List of LogRecord objects.
     * @return List of newly detected threats.
     */
    std::vector<DetectedThreat> detectThreats(const std::vector<LogRecord>& records);

    /**
     * @brief Get list of detected threats from last analysis.
     */
    const std::vector<DetectedThreat>& getDetectedThreats() const { return detectedThreats; }

    /**
     * @brief Load configuration from a simple JSON/text file.
     */
    bool loadConfigFromFile(const std::string& path);

    /**
     * @brief Save current configuration to a JSON/text file.
     */
    bool saveConfigToFile(const std::string& path) const;

private:
    DetectionConfig config;
    std::vector<DetectedThreat> detectedThreats;

    // Independent detection algorithms for the 4 core threat categories
    void detectBruteForce(const std::string& ip, const std::vector<LogRecord>& records, std::vector<DetectedThreat>& outThreats);
    void detectPortScan(const std::string& ip, const std::vector<LogRecord>& records, std::vector<DetectedThreat>& outThreats);
    void detectUnauthorizedAccess(const std::string& ip, const std::vector<LogRecord>& records, std::vector<DetectedThreat>& outThreats);
    void detectRequestFlooding(const std::string& ip, const std::vector<LogRecord>& records, std::vector<DetectedThreat>& outThreats);
};

#endif // THREATDETECTOR_H
