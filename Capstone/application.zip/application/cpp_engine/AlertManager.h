#ifndef ALERTMANAGER_H
#define ALERTMANAGER_H

#include "ThreatDetector.h"
#include "LogAnalyzer.h"
#include <vector>
#include <string>
#include <map>
#include <memory>

/**
 * @struct SecurityAlert
 * @brief Represents a persistent security incident managed by SOC analysts.
 */
struct SecurityAlert {
    std::string alertId;
    std::string attackCategory;
    std::string sourceIp;
    std::string timestamp;
    int64_t epochSeconds = 0;
    int suspiciousEventCount = 0;
    std::string severity;       // "HIGH", "MEDIUM", "LOW"
    std::string explanation;
    std::string ruleTriggered;
    std::string status;         // "New", "Investigating", "Resolved", "False Positive"
    std::string createdAt;
    std::string updatedAt;

    std::string getFingerprint() const {
        return attackCategory + "|" + sourceIp + "|" + timestamp;
    }
};

/**
 * @struct ReportSummary
 * @brief Aggregated metrics for SOC reporting.
 */
struct ReportSummary {
    int totalAlerts = 0;
    int highSeverityCount = 0;
    int mediumSeverityCount = 0;
    int lowSeverityCount = 0;
    int newCount = 0;
    int investigatingCount = 0;
    int resolvedCount = 0;
    int falsePositiveCount = 0;
    std::map<std::string, int> categoryDistribution;
    std::map<std::string, int> suspiciousIpCounts;
};

/**
 * @class AlertManager
 * @brief Module 4: Converts detected threats to persistent alerts, tracks incident status,
 * and generates downloadable security reports.
 */
class AlertManager {
public:
    AlertManager();
    explicit AlertManager(const std::string& storePath);
    ~AlertManager() = default;

    /**
     * @brief Ingest detected threats from Module 3 and merge into persistent alerts.
     */
    void ingestThreats(const std::vector<DetectedThreat>& threats);

    /**
     * @brief Load alerts from persistent file.
     */
    bool loadFromStore(const std::string& storePath);

    /**
     * @brief Save alerts to persistent file.
     */
    bool saveToStore(const std::string& storePath) const;

    /**
     * @brief Update the incident status of a specific alert.
     */
    bool updateStatus(const std::string& alertId, const std::string& newStatus);

    /**
     * @brief Filter alerts by status, severity, category, or IP.
     */
    std::vector<SecurityAlert> filterAlerts(const std::string& categoryFilter,
                                           const std::string& severityFilter,
                                           const std::string& statusFilter,
                                           const std::string& searchKeyword) const;

    /**
     * @brief Generate comprehensive CSV report file.
     */
    bool generateCsvReport(const std::string& outputPath, const AnalysisMetrics* metrics = nullptr) const;

    // Getters
    const std::vector<SecurityAlert>& getAllAlerts() const { return alerts; }
    ReportSummary getReportSummary() const;
    const std::string& getStorePath() const { return persistencePath; }
    void setStorePath(const std::string& path) { persistencePath = path; }

private:
    std::vector<SecurityAlert> alerts;
    std::string persistencePath;
    int nextAlertNumber = 1;

    std::string generateUniqueAlertId();
    std::string getCurrentDateTimeString() const;
};

#endif // ALERTMANAGER_H
