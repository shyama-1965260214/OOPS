#include "LogCollector.h"
#include <iostream>
#include <fstream>
#include <sstream>

LogCollector::LogCollector() : totalLinesRead(0), currentFilePath("") {}

void LogCollector::clear() {
    validRecords.clear();
    validationErrors.clear();
    totalLinesRead = 0;
    currentFilePath.clear();
}

bool LogCollector::loadFromFile(const std::string& filePath) {
    clear();
    currentFilePath = filePath;

    std::ifstream file(filePath);
    if (!file.is_open()) {
        std::cerr << "[LogCollector ERROR] Unable to open log file: " << filePath << std::endl;
        return false;
    }

    std::string line;
    int lineNum = 0;
    bool isFirstLine = true;

    while (std::getline(file, line)) {
        lineNum++;
        totalLinesRead++;

        // Strip UTF-8 BOM if present on first line
        if (lineNum == 1 && line.size() >= 3 && 
            static_cast<unsigned char>(line[0]) == 0xEF &&
            static_cast<unsigned char>(line[1]) == 0xBB &&
            static_cast<unsigned char>(line[2]) == 0xBF) {
            line = line.substr(3);
        }

        std::string trimmedLine = LogUtils::trim(line);
        if (trimmedLine.empty() || trimmedLine[0] == '#') {
            continue; // Ignore blank lines and comments
        }

        // Check if first line is a CSV header
        if (isFirstLine) {
            isFirstLine = false;
            std::string lowerLine = trimmedLine;
            for (char &c : lowerLine) c = std::tolower(static_cast<unsigned char>(c));

            std::vector<std::string> testFields = LogUtils::splitCsvLine(trimmedLine);
            int64_t dummyEpoch = 0;
            bool firstColIsDate = (!testFields.empty() && LogUtils::parseTimestamp(testFields[0], dummyEpoch));

            if (!firstColIsDate && (lowerLine.find("timestamp") != std::string::npos || 
                                    lowerLine.find("source") != std::string::npos ||
                                    lowerLine.find("ip") != std::string::npos ||
                                    lowerLine.find("event") != std::string::npos ||
                                    lowerLine.find("time") != std::string::npos ||
                                    lowerLine.find("date") != std::string::npos)) {
                // Header row detected, skip without marking as error
                continue;
            }
        }

        LogRecord record;
        std::string errorReason;
        if (parseAndValidateLine(lineNum, trimmedLine, record, errorReason)) {
            record.id = static_cast<int>(validRecords.size() + 1);
            record.rawLine = trimmedLine;
            record.isValid = true;
            validRecords.push_back(record);
        } else {
            ValidationError err;
            err.lineNumber = lineNum;
            err.rawLine = trimmedLine;
            err.reason = errorReason;
            validationErrors.push_back(err);
        }
    }

    file.close();
    std::cout << "[LogCollector] Processed file: " << filePath 
              << " | Total: " << totalLinesRead 
              << " | Valid: " << validRecords.size() 
              << " | Invalid: " << validationErrors.size() << std::endl;
    return true;
}

bool LogCollector::parseAndValidateLine(int lineNum, const std::string& line, LogRecord& outRecord, std::string& outError) {
    std::vector<std::string> fields = LogUtils::splitCsvLine(line);

    // Minimum required fields: timestamp, source_ip, username, event_type (at least 4 fields)
    if (fields.size() < 4) {
        outError = "Insufficient columns: expected at least 4 (timestamp, source_ip, username, event_type), found " + std::to_string(fields.size());
        return false;
    }

    std::string rawTimestamp = fields[0];
    std::string rawIp = fields[1];
    std::string rawUser = fields[2];
    std::string rawEventType = fields[3];
    std::string rawPort = (fields.size() > 4) ? fields[4] : "";
    std::string rawStatus = (fields.size() > 5) ? fields[5] : "";

    // 1. Validate Timestamp
    int64_t epoch = 0;
    if (!LogUtils::parseTimestamp(rawTimestamp, epoch)) {
        outError = "Malformed timestamp format: '" + rawTimestamp + "'. Expected format: YYYY-MM-DD HH:MM:SS";
        return false;
    }

    // 2. Validate Source IP
    if (!LogUtils::isValidIPv4(rawIp)) {
        outError = "Invalid IPv4 address format: '" + rawIp + "'";
        return false;
    }

    // 3. Validate Event Type
    if (rawEventType.empty()) {
        outError = "Missing event_type";
        return false;
    }

    // 4. Validate Port (Optional field)
    int port = -1;
    if (!rawPort.empty() && rawPort != "-" && rawPort != "N/A" && 
        rawPort != "null" && rawPort != "None" && rawPort != "none") {
        try {
            port = std::stoi(rawPort);
            if (port < 1 || port > 65535) {
                outError = "Port number out of valid range (1-65535): '" + rawPort + "'";
                return false;
            }
        } catch (...) {
            outError = "Non-numeric destination port: '" + rawPort + "'";
            return false;
        }
    }

    // Construct valid record
    outRecord.timestamp = rawTimestamp;
    outRecord.epochSeconds = epoch;
    outRecord.sourceIp = rawIp;
    outRecord.username = rawUser;
    outRecord.eventType = rawEventType;
    outRecord.destinationPort = port;
    outRecord.status = rawStatus.empty() ? "INFO" : rawStatus;

    return true;
}
