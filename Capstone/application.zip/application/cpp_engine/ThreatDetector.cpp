#include "ThreatDetector.h"
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>

ThreatDetector::ThreatDetector() : config(DetectionConfig()) {}

ThreatDetector::ThreatDetector(const DetectionConfig& cfg) : config(cfg) {}

std::vector<DetectedThreat> ThreatDetector::detectThreats(const std::vector<LogRecord>& records) {
    detectedThreats.clear();
    if (records.empty()) {
        return detectedThreats;
    }

    // 1. Group records by source IP
    std::map<std::string, std::vector<LogRecord>> ipGroups;
    for (const auto& r : records) {
        ipGroups[r.sourceIp].push_back(r);
    }

    // 2. Process each IP chronologically
    int threatCounter = 1;
    for (auto& pair : ipGroups) {
        const std::string& ip = pair.first;
        auto& ipRecords = pair.second;

        // Sort chronologically by epoch
        std::sort(ipRecords.begin(), ipRecords.end(), [](const LogRecord& a, const LogRecord& b) {
            return a.epochSeconds < b.epochSeconds;
        });

        std::vector<DetectedThreat> ipThreats;

        // Execute all 4 detection algorithms
        detectBruteForce(ip, ipRecords, ipThreats);
        detectPortScan(ip, ipRecords, ipThreats);
        detectUnauthorizedAccess(ip, ipRecords, ipThreats);
        detectRequestFlooding(ip, ipRecords, ipThreats);

        // Assign IDs and append
        for (auto& t : ipThreats) {
            t.threatId = "THR-" + std::to_string(threatCounter++);
            detectedThreats.push_back(t);
        }
    }

    // Sort detected threats chronologically
    std::sort(detectedThreats.begin(), detectedThreats.end(), [](const DetectedThreat& a, const DetectedThreat& b) {
        return a.epochSeconds < b.epochSeconds;
    });

    std::cout << "[ThreatDetector] Detection complete. Total threats flagged: " 
              << detectedThreats.size() << std::endl;

    return detectedThreats;
}

// ATTACK 1: BRUTE-FORCE LOGIN DETECTION
void ThreatDetector::detectBruteForce(const std::string& ip, 
                                     const std::vector<LogRecord>& records, 
                                     std::vector<DetectedThreat>& outThreats) {
    std::vector<LogRecord> failedLogins;
    for (const auto& r : records) {
        std::string ev = r.eventType;
        std::string st = r.status;
        for (char &c : ev) c = std::toupper(static_cast<unsigned char>(c));
        for (char &c : st) c = std::toupper(static_cast<unsigned char>(c));

        bool isLogin = (ev.find("LOGIN") != std::string::npos || ev.find("AUTH") != std::string::npos);
        if (ev == "LOGIN_FAILED" || ev == "AUTH_FAILED" || (isLogin && (st == "FAILED" || st == "FAILURE"))) {
            failedLogins.push_back(r);
        }
    }

    if (static_cast<int>(failedLogins.size()) < config.bruteForceThreshold) {
        return;
    }

    size_t n = failedLogins.size();
    size_t i = 0;
    while (i < n) {
        int64_t windowStart = failedLogins[i].epochSeconds;
        int64_t windowEnd = windowStart + config.bruteForceWindowSec;
        size_t j = i;
        while (j < n && failedLogins[j].epochSeconds <= windowEnd) {
            j++;
        }
        int count = static_cast<int>(j - i);
        if (count >= config.bruteForceThreshold) {
            DetectedThreat threat;
            threat.attackCategory = "Brute-Force Login";
            threat.sourceIp = ip;
            threat.timestamp = failedLogins[j - 1].timestamp; // Timestamp when threshold reached
            threat.epochSeconds = failedLogins[j - 1].epochSeconds;
            threat.suspiciousEventCount = count;
            threat.severity = config.bruteForceSeverity;
            threat.ruleTriggered = "RULE_BRUTE_FORCE_01";
            threat.timeWindowDescription = std::to_string(count) + " failed logins within " + 
                                           std::to_string(config.bruteForceWindowSec) + "s window";
            threat.explanation = "Potential threat detected: Source IP " + ip + 
                                 " generated " + std::to_string(count) + 
                                 " failed login attempts between " + failedLogins[i].timestamp + 
                                 " and " + failedLogins[j - 1].timestamp + 
                                 ", exceeding threshold of " + std::to_string(config.bruteForceThreshold) + 
                                 " in a " + std::to_string(config.bruteForceWindowSec / 60) + "-minute window.";
            outThreats.push_back(threat);
            // Move window forward past this detected burst to deduplicate
            i = j;
        } else {
            i++;
        }
    }
}

// ATTACK 2: PORT SCANNING DETECTION
void ThreatDetector::detectPortScan(const std::string& ip, 
                                   const std::vector<LogRecord>& records, 
                                   std::vector<DetectedThreat>& outThreats) {
    std::vector<LogRecord> portRecords;
    for (const auto& r : records) {
        if (r.destinationPort > 0) {
            portRecords.push_back(r);
        }
    }

    if (static_cast<int>(portRecords.size()) < config.portScanThreshold) {
        return;
    }

    size_t n = portRecords.size();
    size_t i = 0;
    while (i < n) {
        int64_t windowStart = portRecords[i].epochSeconds;
        int64_t windowEnd = windowStart + config.portScanWindowSec;
        std::set<int> uniquePorts;
        size_t j = i;
        while (j < n && portRecords[j].epochSeconds <= windowEnd) {
            uniquePorts.insert(portRecords[j].destinationPort);
            j++;
        }
        int distinctPortCount = static_cast<int>(uniquePorts.size());
        if (distinctPortCount >= config.portScanThreshold) {
            DetectedThreat threat;
            threat.attackCategory = "Port Scanning";
            threat.sourceIp = ip;
            threat.timestamp = portRecords[j - 1].timestamp;
            threat.epochSeconds = portRecords[j - 1].epochSeconds;
            threat.suspiciousEventCount = distinctPortCount;
            threat.severity = config.portScanSeverity;
            threat.ruleTriggered = "RULE_PORT_SCAN_02";
            threat.timeWindowDescription = std::to_string(distinctPortCount) + " distinct ports probed within " + 
                                           std::to_string(config.portScanWindowSec) + "s window";
            threat.explanation = "Potential threat detected: Source IP " + ip + 
                                 " attempted connections across " + std::to_string(distinctPortCount) + 
                                 " distinct destination ports between " + portRecords[i].timestamp + 
                                 " and " + portRecords[j - 1].timestamp + 
                                 ", exceeding threshold of " + std::to_string(config.portScanThreshold) + 
                                 " distinct ports within a " + std::to_string(config.portScanWindowSec / 60) + "-minute window.";
            outThreats.push_back(threat);
            // Move window forward past this scan burst to deduplicate
            i = j;
        } else {
            i++;
        }
    }
}

// ATTACK 3: UNAUTHORIZED RESOURCE ACCESS
void ThreatDetector::detectUnauthorizedAccess(const std::string& ip, 
                                             const std::vector<LogRecord>& records, 
                                             std::vector<DetectedThreat>& outThreats) {
    std::vector<LogRecord> deniedRecords;
    for (const auto& r : records) {
        std::string ev = r.eventType;
        std::string st = r.status;
        for (char &c : ev) c = std::toupper(static_cast<unsigned char>(c));
        for (char &c : st) c = std::toupper(static_cast<unsigned char>(c));

        if (ev == "ACCESS_DENIED" || ev == "UNAUTHORIZED_ACCESS" || 
            st == "DENIED" || st == "RESTRICTED" || st == "FORBIDDEN") {
            deniedRecords.push_back(r);
        }
    }

    if (static_cast<int>(deniedRecords.size()) < config.unauthorizedThreshold) {
        return;
    }

    size_t n = deniedRecords.size();
    size_t i = 0;
    while (i < n) {
        int64_t windowStart = deniedRecords[i].epochSeconds;
        int64_t windowEnd = windowStart + config.unauthorizedWindowSec;
        size_t j = i;
        while (j < n && deniedRecords[j].epochSeconds <= windowEnd) {
            j++;
        }
        int count = static_cast<int>(j - i);
        if (count >= config.unauthorizedThreshold) {
            DetectedThreat threat;
            threat.attackCategory = "Unauthorized Resource Access";
            threat.sourceIp = ip;
            threat.timestamp = deniedRecords[j - 1].timestamp;
            threat.epochSeconds = deniedRecords[j - 1].epochSeconds;
            threat.suspiciousEventCount = count;
            threat.severity = config.unauthorizedSeverity;
            threat.ruleTriggered = "RULE_UNAUTH_ACCESS_03";
            threat.timeWindowDescription = std::to_string(count) + " unauthorized attempts within " + 
                                           std::to_string(config.unauthorizedWindowSec) + "s window";
            threat.explanation = "Potential threat detected: Source IP " + ip + 
                                 " generated " + std::to_string(count) + 
                                 " denied or restricted resource access requests between " + 
                                 deniedRecords[i].timestamp + " and " + deniedRecords[j - 1].timestamp + 
                                 ", exceeding threshold of " + std::to_string(config.unauthorizedThreshold) + 
                                 " in a " + std::to_string(config.unauthorizedWindowSec / 60) + "-minute window.";
            outThreats.push_back(threat);
            // Move window forward past this incident to deduplicate
            i = j;
        } else {
            i++;
        }
    }
}

// ATTACK 4: REQUEST FLOODING
void ThreatDetector::detectRequestFlooding(const std::string& ip, 
                                          const std::vector<LogRecord>& records, 
                                          std::vector<DetectedThreat>& outThreats) {
    if (static_cast<int>(records.size()) < config.requestFloodThreshold) {
        return;
    }

    size_t n = records.size();
    size_t i = 0;
    while (i < n) {
        int64_t windowStart = records[i].epochSeconds;
        int64_t windowEnd = windowStart + config.requestFloodWindowSec;
        size_t j = i;
        while (j < n && records[j].epochSeconds <= windowEnd) {
            j++;
        }
        int count = static_cast<int>(j - i);
        if (count >= config.requestFloodThreshold) {
            DetectedThreat threat;
            threat.attackCategory = "Request Flooding";
            threat.sourceIp = ip;
            threat.timestamp = records[j - 1].timestamp;
            threat.epochSeconds = records[j - 1].epochSeconds;
            threat.suspiciousEventCount = count;
            threat.severity = config.requestFloodSeverity;
            threat.ruleTriggered = "RULE_REQUEST_FLOOD_04";
            threat.timeWindowDescription = std::to_string(count) + " requests within " + 
                                           std::to_string(config.requestFloodWindowSec) + "s window";
            threat.explanation = "Potential threat detected: Source IP " + ip + 
                                 " initiated " + std::to_string(count) + 
                                 " requests between " + records[i].timestamp + 
                                 " and " + records[j - 1].timestamp + 
                                 ", exceeding rate limit threshold of " + 
                                 std::to_string(config.requestFloodThreshold) + 
                                 " requests within a " + std::to_string(config.requestFloodWindowSec) + "-second window.";
            outThreats.push_back(threat);
            // Move window forward past this flood window to deduplicate
            i = j;
        } else {
            i++;
        }
    }
}

bool ThreatDetector::loadConfigFromFile(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return false;

    std::string line;
    while (std::getline(file, line)) {
        std::string trimmed = LogUtils::trim(line);
        if (trimmed.empty() || trimmed[0] == '#' || trimmed[0] == '{' || trimmed[0] == '}') continue;

        // Parse key: value or "key": value
        size_t colonPos = trimmed.find(':');
        if (colonPos == std::string::npos) colonPos = trimmed.find('=');
        if (colonPos == std::string::npos) continue;

        std::string key = LogUtils::trim(trimmed.substr(0, colonPos));
        std::string val = LogUtils::trim(trimmed.substr(colonPos + 1));

        // Strip quotes and trailing commas
        if (!key.empty() && key.front() == '\"') key = key.substr(1);
        if (!key.empty() && key.back() == '\"') key.pop_back();
        while (!val.empty() && (val.back() == ',' || val.back() == '\"' || val.back() == '\r')) {
            val.pop_back();
        }
        if (!val.empty() && val.front() == '\"') val = val.substr(1);

        try {
            if (key == "bruteForceThreshold") config.bruteForceThreshold = std::stoi(val);
            else if (key == "bruteForceWindowSec") config.bruteForceWindowSec = std::stoi(val);
            else if (key == "bruteForceSeverity") config.bruteForceSeverity = val;
            else if (key == "portScanThreshold") config.portScanThreshold = std::stoi(val);
            else if (key == "portScanWindowSec") config.portScanWindowSec = std::stoi(val);
            else if (key == "portScanSeverity") config.portScanSeverity = val;
            else if (key == "unauthorizedThreshold") config.unauthorizedThreshold = std::stoi(val);
            else if (key == "unauthorizedWindowSec") config.unauthorizedWindowSec = std::stoi(val);
            else if (key == "unauthorizedSeverity") config.unauthorizedSeverity = val;
            else if (key == "requestFloodThreshold") config.requestFloodThreshold = std::stoi(val);
            else if (key == "requestFloodWindowSec") config.requestFloodWindowSec = std::stoi(val);
            else if (key == "requestFloodSeverity") config.requestFloodSeverity = val;
        } catch (...) {
            // Ignore parse errors on individual fields
        }
    }
    file.close();
    return true;
}

bool ThreatDetector::saveConfigToFile(const std::string& path) const {
    std::ofstream file(path);
    if (!file.is_open()) return false;

    file << "{\n";
    file << "  \"bruteForceThreshold\": " << config.bruteForceThreshold << ",\n";
    file << "  \"bruteForceWindowSec\": " << config.bruteForceWindowSec << ",\n";
    file << "  \"bruteForceSeverity\": \"" << config.bruteForceSeverity << "\",\n";
    file << "  \"portScanThreshold\": " << config.portScanThreshold << ",\n";
    file << "  \"portScanWindowSec\": " << config.portScanWindowSec << ",\n";
    file << "  \"portScanSeverity\": \"" << config.portScanSeverity << "\",\n";
    file << "  \"unauthorizedThreshold\": " << config.unauthorizedThreshold << ",\n";
    file << "  \"unauthorizedWindowSec\": " << config.unauthorizedWindowSec << ",\n";
    file << "  \"unauthorizedSeverity\": \"" << config.unauthorizedSeverity << "\",\n";
    file << "  \"requestFloodThreshold\": " << config.requestFloodThreshold << ",\n";
    file << "  \"requestFloodWindowSec\": " << config.requestFloodWindowSec << ",\n";
    file << "  \"requestFloodSeverity\": \"" << config.requestFloodSeverity << "\"\n";
    file << "}\n";

    file.close();
    return true;
}
