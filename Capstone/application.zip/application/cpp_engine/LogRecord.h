#ifndef LOGRECORD_H
#define LOGRECORD_H

#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <cstdint>
#include <algorithm>
#include <cctype>

/**
 * @struct LogRecord
 * @brief Represents a parsed and validated system/network log entry.
 */
struct LogRecord {
    int id = 0;                     // Sequence ID
    std::string timestamp;          // Formatted timestamp string: YYYY-MM-DD HH:MM:SS
    int64_t epochSeconds = 0;       // Seconds since Unix epoch for time-window calculations
    std::string sourceIp;           // Source IPv4 address
    std::string username;           // Target or acting username
    std::string eventType;          // Event identifier (e.g., LOGIN_FAILED, PORT_SCAN)
    int destinationPort = -1;       // Destination port (1-65535, or -1 if none)
    std::string status;             // Event status (e.g., SUCCESS, FAILED, DENIED)
    bool isValid = false;           // Validation flag
    std::string rawLine;            // Original unparsed log line
};

namespace LogUtils {

    /**
     * @brief Trim leading and trailing whitespace safely without iterator underflow.
     */
    inline std::string trim(const std::string& s) {
        if (s.empty()) return "";
        size_t first = s.find_first_not_of(" \t\r\n");
        if (first == std::string::npos) return "";
        size_t last = s.find_last_not_of(" \t\r\n");
        return s.substr(first, (last - first + 1));
    }

    /**
     * @brief Validate an IPv4 address string (e.g. 192.168.1.1).
     */
    inline bool isValidIPv4(const std::string& ip) {
        if (ip.empty() || ip.length() > 15) return false;
        int dots = 0;
        int octet = 0;
        int octetDigits = 0;
        for (size_t i = 0; i < ip.length(); ++i) {
            char c = ip[i];
            if (c == '.') {
                if (octetDigits == 0 || octetDigits > 3) return false;
                if (octet < 0 || octet > 255) return false;
                dots++;
                octet = 0;
                octetDigits = 0;
            } else if (std::isdigit(static_cast<unsigned char>(c))) {
                octet = octet * 10 + (c - '0');
                octetDigits++;
                if (octetDigits > 1 && ip[i - octetDigits + 1] == '0') {
                    // Disallow leading zeros like "01" unless it's just "0"
                    return false;
                }
            } else {
                return false;
            }
        }
        if (dots != 3 || octetDigits == 0 || octetDigits > 3 || octet < 0 || octet > 255) {
            return false;
        }
        return true;
    }

    /**
     * @brief Parse a timestamp string "YYYY-MM-DD HH:MM:SS" into epoch seconds.
     */
    inline bool parseTimestamp(const std::string& str, int64_t& outEpoch) {
        std::string s = trim(str);
        if (s.length() < 19) return false;

        // Support ISO format with 'T' or space
        char dateSep1 = s[4];
        char dateSep2 = s[7];
        char timeSep1 = s[13];
        char timeSep2 = s[16];

        if ((dateSep1 != '-' && dateSep1 != '/') || (dateSep2 != '-' && dateSep2 != '/') || timeSep1 != ':' || timeSep2 != ':') {
            return false;
        }

        try {
            int year = std::stoi(s.substr(0, 4));
            int month = std::stoi(s.substr(5, 2));
            int day = std::stoi(s.substr(8, 2));
            int hour = std::stoi(s.substr(11, 2));
            int minute = std::stoi(s.substr(14, 2));
            int second = std::stoi(s.substr(17, 2));

            if (year < 1970 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31 ||
                hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) {
                return false;
            }

            // Calculate epoch seconds directly for reliability across platforms
            // Cumulative days up to the month for standard year
            static const int daysBeforeMonth[13] = {
                0, 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334
            };

            auto isLeapYear = [](int y) {
                return (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
            };

            int64_t days = 0;
            for (int y = 1970; y < year; ++y) {
                days += isLeapYear(y) ? 366 : 365;
            }
            days += daysBeforeMonth[month];
            if (month > 2 && isLeapYear(year)) {
                days += 1;
            }
            days += (day - 1);

            outEpoch = days * 86400LL + hour * 3600LL + minute * 60LL + second;
            return true;
        } catch (...) {
            return false;
        }
    }

    /**
     * @brief Split a CSV line respecting quoted fields.
     */
    inline std::vector<std::string> splitCsvLine(const std::string& line) {
        std::vector<std::string> fields;
        std::string current;
        bool inQuotes = false;

        for (size_t i = 0; i < line.length(); ++i) {
            char c = line[i];
            if (c == '\"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                fields.push_back(trim(current));
                current.clear();
            } else if (c != '\r') {
                current += c;
            }
        }
        fields.push_back(trim(current));
        return fields;
    }
}

#endif // LOGRECORD_H
