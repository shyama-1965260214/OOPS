#include "LogAnalyzer.h"
#include <set>
#include <algorithm>
#include <iomanip>
#include <sstream>

LogAnalyzer::LogAnalyzer() {}

void LogAnalyzer::analyze(const std::vector<LogRecord>& records) {
    metrics = AnalysisMetrics();
    ipGroups.clear();

    if (records.empty()) {
        return;
    }

    metrics.totalEvents = static_cast<int>(records.size());

    // 1. Group records by IP
    groupRecordsByIp(records);

    // 2. Compute login statistics and event distributions
    computeLoginCounts(records);
    computeEventDistribution(records);

    // 3. Compute active IP ranking and per-IP metrics
    computeActiveIps();

    // 4. Compute activity timeline
    computeTimeline(records);
}

void LogAnalyzer::groupRecordsByIp(const std::vector<LogRecord>& records) {
    for (const auto& rec : records) {
        ipGroups[rec.sourceIp].push_back(rec);
    }
    metrics.uniqueIpCount = static_cast<int>(ipGroups.size());
}

void LogAnalyzer::computeLoginCounts(const std::vector<LogRecord>& records) {
    int successes = 0;
    int failures = 0;
    int others = 0;

    for (const auto& rec : records) {
        std::string ev = rec.eventType;
        std::string st = rec.status;
        for (char &c : ev) c = std::toupper(static_cast<unsigned char>(c));
        for (char &c : st) c = std::toupper(static_cast<unsigned char>(c));

        bool isLogin = (ev.find("LOGIN") != std::string::npos || ev.find("AUTH") != std::string::npos);

        if (ev == "LOGIN_SUCCESS" || (isLogin && st == "SUCCESS")) {
            successes++;
        } else if (ev == "LOGIN_FAILED" || ev == "AUTH_FAILED" || (isLogin && (st == "FAILED" || st == "FAILURE"))) {
            failures++;
        } else {
            others++;
        }
    }

    metrics.successfulLogins = successes;
    metrics.failedLogins = failures;
    metrics.otherEvents = others;
}

void LogAnalyzer::computeEventDistribution(const std::vector<LogRecord>& records) {
    for (const auto& rec : records) {
        metrics.eventDistribution[rec.eventType]++;
    }
}

void LogAnalyzer::computeActiveIps() {
    metrics.mostActiveIps.clear();
    metrics.repeatedLoginFailures.clear();

    for (const auto& pair : ipGroups) {
        const std::string& ip = pair.first;
        const auto& recs = pair.second;

        IpActivity act;
        act.ip = ip;
        act.totalEvents = static_cast<int>(recs.size());

        std::set<int> uniquePorts;

        for (const auto& r : recs) {
            std::string ev = r.eventType;
            std::string st = r.status;
            for (char &c : ev) c = std::toupper(static_cast<unsigned char>(c));
            for (char &c : st) c = std::toupper(static_cast<unsigned char>(c));

            bool isLogin = (ev.find("LOGIN") != std::string::npos || ev.find("AUTH") != std::string::npos);

            if (ev == "LOGIN_FAILED" || ev == "AUTH_FAILED" || (isLogin && (st == "FAILED" || st == "FAILURE"))) {
                act.failedLogins++;
            } else if (ev == "LOGIN_SUCCESS" || (isLogin && st == "SUCCESS")) {
                act.successfulLogins++;
            }

            if (ev == "ACCESS_DENIED" || ev == "UNAUTHORIZED_ACCESS" || st == "DENIED" || st == "RESTRICTED") {
                act.deniedAccessCount++;
            }

            if (r.destinationPort > 0) {
                uniquePorts.insert(r.destinationPort);
            }
        }

        act.uniquePortsProbed = static_cast<int>(uniquePorts.size());
        metrics.mostActiveIps.push_back(act);

        if (act.failedLogins > 1) {
            metrics.repeatedLoginFailures[ip] = act.failedLogins;
        }
    }

    // Sort IP activity descending by totalEvents
    std::sort(metrics.mostActiveIps.begin(), metrics.mostActiveIps.end(), [](const IpActivity& a, const IpActivity& b) {
        if (a.totalEvents != b.totalEvents) return a.totalEvents > b.totalEvents;
        return a.failedLogins > b.failedLogins;
    });
}

void LogAnalyzer::computeTimeline(const std::vector<LogRecord>& records) {
    metrics.activityTimeline.clear();
    if (records.empty()) return;

    // Find min and max timestamp
    int64_t minEpoch = records[0].epochSeconds;
    int64_t maxEpoch = records[0].epochSeconds;

    for (const auto& r : records) {
        if (r.epochSeconds < minEpoch) minEpoch = r.epochSeconds;
        if (r.epochSeconds > maxEpoch) maxEpoch = r.epochSeconds;
    }

    // Choose bucket size: e.g. 300 seconds (5 min) or 60 seconds (1 min) depending on range
    int64_t range = maxEpoch - minEpoch;
    int64_t bucketInterval = (range > 7200) ? 600 : (range > 1800 ? 300 : 60);
    if (bucketInterval < 60) bucketInterval = 60;

    std::map<int64_t, int> bucketCounts;
    for (const auto& r : records) {
        int64_t bucketStart = (r.epochSeconds / bucketInterval) * bucketInterval;
        bucketCounts[bucketStart]++;
    }

    for (const auto& pair : bucketCounts) {
        TimelineBucket b;
        b.epochStart = pair.first;
        b.eventCount = pair.second;

        // Convert epoch to HH:MM format
        time_t t = static_cast<time_t>(pair.first);
        struct tm tmBuf;
#if defined(_WIN32)
        gmtime_s(&tmBuf, &t);
#else
        gmtime_r(&t, &tmBuf);
#endif
        char buf[32];
        std::snprintf(buf, sizeof(buf), "%02d:%02d", tmBuf.tm_hour, tmBuf.tm_min);
        b.timeLabel = std::string(buf);

        metrics.activityTimeline.push_back(b);
    }
}

std::vector<LogRecord> LogAnalyzer::filterRecords(const std::vector<LogRecord>& sourceRecords,
                                                  const std::string& ipFilter,
                                                  const std::string& eventFilter,
                                                  int64_t startEpoch,
                                                  int64_t endEpoch) const {
    std::vector<LogRecord> filtered;
    for (const auto& r : sourceRecords) {
        if (!ipFilter.empty() && r.sourceIp.find(ipFilter) == std::string::npos) {
            continue;
        }
        if (!eventFilter.empty() && r.eventType.find(eventFilter) == std::string::npos) {
            continue;
        }
        if (startEpoch > 0 && r.epochSeconds < startEpoch) {
            continue;
        }
        if (endEpoch > 0 && r.epochSeconds > endEpoch) {
            continue;
        }
        filtered.push_back(r);
    }
    return filtered;
}
