#include "LogCollector.h"
#include "LogAnalyzer.h"
#include "ThreatDetector.h"
#include "AlertManager.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <sstream>

// Forward declaration of standalone test runner
int runStandaloneTests();

static std::string jsonEscape(const std::string& s) {
    std::string res;
    for (char c : s) {
        if (c == '\"') res += "\\\"";
        else if (c == '\\') res += "\\\\";
        else if (c == '\n') res += "\\n";
        else if (c == '\r') res += "\\r";
        else if (c == '\t') res += "\\t";
        else res += c;
    }
    return res;
}

std::string buildFullJsonOutput(const LogCollector& collector,
                                const LogAnalyzer& analyzer,
                                const std::vector<DetectedThreat>& threats,
                                const AlertManager& alertManager) {
    std::ostringstream ss;
    const auto& validRecs = collector.getValidRecords();
    const auto& errors = collector.getValidationErrors();
    const auto& metrics = analyzer.getMetrics();
    const auto& alerts = alertManager.getAllAlerts();
    ReportSummary summary = alertManager.getReportSummary();

    ss << "{\n";
    ss << "  \"status\": \"success\",\n";

    // 1. Collection Module
    ss << "  \"collection\": {\n";
    ss << "    \"totalLines\": " << collector.getTotalLinesRead() << ",\n";
    ss << "    \"validRecords\": " << collector.getValidCount() << ",\n";
    ss << "    \"invalidRecords\": " << collector.getInvalidCount() << ",\n";
    ss << "    \"filePath\": \"" << jsonEscape(collector.getLoadedFilePath()) << "\",\n";
    
    // Sample / parsed records (all valid records for frontend tables)
    ss << "    \"records\": [\n";
    for (size_t i = 0; i < validRecs.size(); ++i) {
        const auto& r = validRecs[i];
        ss << "      {\"id\": " << r.id 
           << ", \"timestamp\": \"" << jsonEscape(r.timestamp) << "\""
           << ", \"sourceIp\": \"" << jsonEscape(r.sourceIp) << "\""
           << ", \"username\": \"" << jsonEscape(r.username) << "\""
           << ", \"eventType\": \"" << jsonEscape(r.eventType) << "\""
           << ", \"destinationPort\": " << r.destinationPort
           << ", \"status\": \"" << jsonEscape(r.status) << "\"}"
           << (i + 1 < validRecs.size() ? "," : "") << "\n";
    }
    ss << "    ],\n";

    // Validation errors
    ss << "    \"errors\": [\n";
    for (size_t i = 0; i < errors.size(); ++i) {
        const auto& e = errors[i];
        ss << "      {\"lineNumber\": " << e.lineNumber
           << ", \"rawLine\": \"" << jsonEscape(e.rawLine) << "\""
           << ", \"reason\": \"" << jsonEscape(e.reason) << "\"}"
           << (i + 1 < errors.size() ? "," : "") << "\n";
    }
    ss << "    ]\n";
    ss << "  },\n";

    // 2. Analysis Module
    ss << "  \"analysis\": {\n";
    ss << "    \"totalEvents\": " << metrics.totalEvents << ",\n";
    ss << "    \"successfulLogins\": " << metrics.successfulLogins << ",\n";
    ss << "    \"failedLogins\": " << metrics.failedLogins << ",\n";
    ss << "    \"otherEvents\": " << metrics.otherEvents << ",\n";
    ss << "    \"uniqueIps\": " << metrics.uniqueIpCount << ",\n";

    // Event distribution
    ss << "    \"eventDistribution\": {\n";
    size_t k = 0;
    for (const auto& pair : metrics.eventDistribution) {
        ss << "      \"" << jsonEscape(pair.first) << "\": " << pair.second 
           << (++k < metrics.eventDistribution.size() ? "," : "") << "\n";
    }
    ss << "    },\n";

    // Most active IPs
    ss << "    \"mostActiveIps\": [\n";
    for (size_t i = 0; i < metrics.mostActiveIps.size(); ++i) {
        const auto& ipAct = metrics.mostActiveIps[i];
        ss << "      {\"ip\": \"" << jsonEscape(ipAct.ip) << "\""
           << ", \"totalEvents\": " << ipAct.totalEvents
           << ", \"failedLogins\": " << ipAct.failedLogins
           << ", \"successfulLogins\": " << ipAct.successfulLogins
           << ", \"uniquePorts\": " << ipAct.uniquePortsProbed
           << ", \"deniedCount\": " << ipAct.deniedAccessCount << "}"
           << (i + 1 < metrics.mostActiveIps.size() ? "," : "") << "\n";
    }
    ss << "    ],\n";

    // Repeated login failures
    ss << "    \"repeatedFailures\": {\n";
    k = 0;
    for (const auto& pair : metrics.repeatedLoginFailures) {
        ss << "      \"" << jsonEscape(pair.first) << "\": " << pair.second 
           << (++k < metrics.repeatedLoginFailures.size() ? "," : "") << "\n";
    }
    ss << "    },\n";

    // Timeline buckets
    ss << "    \"timeline\": [\n";
    for (size_t i = 0; i < metrics.activityTimeline.size(); ++i) {
        const auto& b = metrics.activityTimeline[i];
        ss << "      {\"timeLabel\": \"" << jsonEscape(b.timeLabel) << "\""
           << ", \"epochStart\": " << b.epochStart
           << ", \"count\": " << b.eventCount << "}"
           << (i + 1 < metrics.activityTimeline.size() ? "," : "") << "\n";
    }
    ss << "    ]\n";
    ss << "  },\n";

    // 3. Threat Detection Module
    ss << "  \"threats\": [\n";
    for (size_t i = 0; i < threats.size(); ++i) {
        const auto& t = threats[i];
        ss << "    {\"threatId\": \"" << jsonEscape(t.threatId) << "\""
           << ", \"attackCategory\": \"" << jsonEscape(t.attackCategory) << "\""
           << ", \"sourceIp\": \"" << jsonEscape(t.sourceIp) << "\""
           << ", \"timestamp\": \"" << jsonEscape(t.timestamp) << "\""
           << ", \"suspiciousEventCount\": " << t.suspiciousEventCount
           << ", \"severity\": \"" << jsonEscape(t.severity) << "\""
           << ", \"ruleTriggered\": \"" << jsonEscape(t.ruleTriggered) << "\""
           << ", \"timeWindow\": \"" << jsonEscape(t.timeWindowDescription) << "\""
           << ", \"explanation\": \"" << jsonEscape(t.explanation) << "\"}"
           << (i + 1 < threats.size() ? "," : "") << "\n";
    }
    ss << "  ],\n";

    // 4. Alert Management Module (Persistent Incidents)
    ss << "  \"alerts\": [\n";
    for (size_t i = 0; i < alerts.size(); ++i) {
        const auto& a = alerts[i];
        ss << "    {\"alertId\": \"" << jsonEscape(a.alertId) << "\""
           << ", \"attackCategory\": \"" << jsonEscape(a.attackCategory) << "\""
           << ", \"sourceIp\": \"" << jsonEscape(a.sourceIp) << "\""
           << ", \"timestamp\": \"" << jsonEscape(a.timestamp) << "\""
           << ", \"suspiciousEventCount\": " << a.suspiciousEventCount
           << ", \"severity\": \"" << jsonEscape(a.severity) << "\""
           << ", \"status\": \"" << jsonEscape(a.status) << "\""
           << ", \"ruleTriggered\": \"" << jsonEscape(a.ruleTriggered) << "\""
           << ", \"explanation\": \"" << jsonEscape(a.explanation) << "\""
           << ", \"createdAt\": \"" << jsonEscape(a.createdAt) << "\""
           << ", \"updatedAt\": \"" << jsonEscape(a.updatedAt) << "\"}"
           << (i + 1 < alerts.size() ? "," : "") << "\n";
    }
    ss << "  ],\n";

    // Summary Statistics for SOC Dashboard
    ss << "  \"summary\": {\n";
    ss << "    \"totalAlerts\": " << summary.totalAlerts << ",\n";
    ss << "    \"highSeverity\": " << summary.highSeverityCount << ",\n";
    ss << "    \"mediumSeverity\": " << summary.mediumSeverityCount << ",\n";
    ss << "    \"lowSeverity\": " << summary.lowSeverityCount << ",\n";
    ss << "    \"newCount\": " << summary.newCount << ",\n";
    ss << "    \"investigatingCount\": " << summary.investigatingCount << ",\n";
    ss << "    \"resolvedCount\": " << summary.resolvedCount << ",\n";
    ss << "    \"falsePositiveCount\": " << summary.falsePositiveCount << ",\n";

    ss << "    \"categoryDistribution\": {\n";
    k = 0;
    for (const auto& pair : summary.categoryDistribution) {
        ss << "      \"" << jsonEscape(pair.first) << "\": " << pair.second 
           << (++k < summary.categoryDistribution.size() ? "," : "") << "\n";
    }
    ss << "    },\n";

    ss << "    \"suspiciousIps\": {\n";
    k = 0;
    for (const auto& pair : summary.suspiciousIpCounts) {
        ss << "      \"" << jsonEscape(pair.first) << "\": " << pair.second 
           << (++k < summary.suspiciousIpCounts.size() ? "," : "") << "\n";
    }
    ss << "    }\n";
    ss << "  }\n";
    ss << "}\n";

    return ss.str();
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "CYBERSHIELD Core Engine (C++17)\n";
        std::cout << "Usage:\n";
        std::cout << "  cybershield_engine --analyze <logfile> [--config <cfg>] [--output <out.json>] [--store <alerts.json>]\n";
        std::cout << "  cybershield_engine --update-alert <alert_id> <status> [--store <alerts.json>]\n";
        std::cout << "  cybershield_engine --generate-report <out_csv> [--store <alerts.json>]\n";
        std::cout << "  cybershield_engine --get-alerts [--store <alerts.json>]\n";
        std::cout << "  cybershield_engine --test\n";
        return 0;
    }

    std::string mode = argv[1];

    if (mode == "--test") {
        return runStandaloneTests();
    }

    // Default file paths
    std::string storePath = "CyberShield/data/alerts_store.json";

    if (mode == "--update-alert") {
        if (argc < 4) {
            std::cerr << "{\"status\": \"error\", \"message\": \"Missing alert_id or new_status arguments\"}\n";
            return 1;
        }
        std::string alertId = argv[2];
        std::string newStatus = argv[3];

        for (int i = 4; i < argc; ++i) {
            if (std::string(argv[i]) == "--store" && i + 1 < argc) {
                storePath = argv[++i];
            }
        }

        AlertManager alertManager(storePath);
        bool success = alertManager.updateStatus(alertId, newStatus);
        if (success) {
            std::cout << "{\"status\": \"success\", \"alertId\": \"" << jsonEscape(alertId) 
                      << "\", \"newStatus\": \"" << jsonEscape(newStatus) << "\"}\n";
            return 0;
        } else {
            std::cerr << "{\"status\": \"error\", \"message\": \"Failed to update alert status\"}\n";
            return 1;
        }
    }

    if (mode == "--generate-report") {
        if (argc < 3) {
            std::cerr << "{\"status\": \"error\", \"message\": \"Missing output_csv argument\"}\n";
            return 1;
        }
        std::string outCsv = argv[2];

        for (int i = 3; i < argc; ++i) {
            if (std::string(argv[i]) == "--store" && i + 1 < argc) {
                storePath = argv[++i];
            }
        }

        AlertManager alertManager(storePath);
        bool success = alertManager.generateCsvReport(outCsv);
        if (success) {
            std::cout << "{\"status\": \"success\", \"reportPath\": \"" << jsonEscape(outCsv) << "\"}\n";
            return 0;
        } else {
            std::cerr << "{\"status\": \"error\", \"message\": \"Failed to generate report\"}\n";
            return 1;
        }
    }

    if (mode == "--get-alerts") {
        for (int i = 2; i < argc; ++i) {
            if (std::string(argv[i]) == "--store" && i + 1 < argc) {
                storePath = argv[++i];
            }
        }

        AlertManager alertManager(storePath);
        const auto& alerts = alertManager.getAllAlerts();
        ReportSummary summary = alertManager.getReportSummary();

        std::ostringstream ss;
        ss << "{\n  \"status\": \"success\",\n  \"alerts\": [\n";
        for (size_t i = 0; i < alerts.size(); ++i) {
            const auto& a = alerts[i];
            ss << "    {\"alertId\": \"" << jsonEscape(a.alertId) << "\""
               << ", \"attackCategory\": \"" << jsonEscape(a.attackCategory) << "\""
               << ", \"sourceIp\": \"" << jsonEscape(a.sourceIp) << "\""
               << ", \"timestamp\": \"" << jsonEscape(a.timestamp) << "\""
               << ", \"suspiciousEventCount\": " << a.suspiciousEventCount
               << ", \"severity\": \"" << jsonEscape(a.severity) << "\""
               << ", \"status\": \"" << jsonEscape(a.status) << "\""
               << ", \"ruleTriggered\": \"" << jsonEscape(a.ruleTriggered) << "\""
               << ", \"explanation\": \"" << jsonEscape(a.explanation) << "\""
               << ", \"createdAt\": \"" << jsonEscape(a.createdAt) << "\""
               << ", \"updatedAt\": \"" << jsonEscape(a.updatedAt) << "\"}"
               << (i + 1 < alerts.size() ? "," : "") << "\n";
        }
        ss << "  ],\n";
        ss << "  \"summary\": {\n";
        ss << "    \"totalAlerts\": " << summary.totalAlerts << ",\n";
        ss << "    \"highSeverity\": " << summary.highSeverityCount << ",\n";
        ss << "    \"mediumSeverity\": " << summary.mediumSeverityCount << ",\n";
        ss << "    \"lowSeverity\": " << summary.lowSeverityCount << ",\n";
        ss << "    \"newCount\": " << summary.newCount << ",\n";
        ss << "    \"investigatingCount\": " << summary.investigatingCount << ",\n";
        ss << "    \"resolvedCount\": " << summary.resolvedCount << ",\n";
        ss << "    \"falsePositiveCount\": " << summary.falsePositiveCount << "\n";
        ss << "  }\n}\n";

        std::cout << ss.str();
        return 0;
    }

    if (mode == "--analyze") {
        if (argc < 3) {
            std::cerr << "{\"status\": \"error\", \"message\": \"Missing logfile path\"}\n";
            return 1;
        }

        std::string logFilePath = argv[2];
        std::string configPath = "";
        std::string outputPath = "";

        for (int i = 3; i < argc; ++i) {
            if (std::string(argv[i]) == "--config" && i + 1 < argc) {
                configPath = argv[++i];
            } else if (std::string(argv[i]) == "--output" && i + 1 < argc) {
                outputPath = argv[++i];
            } else if (std::string(argv[i]) == "--store" && i + 1 < argc) {
                storePath = argv[++i];
            }
        }

        // Module 1: Collect & Validate
        LogCollector collector;
        if (!collector.loadFromFile(logFilePath)) {
            std::cerr << "{\"status\": \"error\", \"message\": \"Failed to read or parse input log file: " 
                      << jsonEscape(logFilePath) << "\"}\n";
            return 1;
        }

        // Module 2: Analyze
        LogAnalyzer analyzer;
        analyzer.analyze(collector.getValidRecords());

        // Module 3: Threat Detection
        ThreatDetector detector;
        if (!configPath.empty()) {
            detector.loadConfigFromFile(configPath);
        }
        auto threats = detector.detectThreats(collector.getValidRecords());

        // Module 4: Alert Management & Persistence
        AlertManager alertManager(storePath);
        alertManager.ingestThreats(threats);

        // Build comprehensive JSON representation
        std::string jsonOutput = buildFullJsonOutput(collector, analyzer, threats, alertManager);

        if (!outputPath.empty()) {
            std::ofstream outFile(outputPath);
            if (outFile.is_open()) {
                outFile << jsonOutput;
                outFile.close();
            }
        }

        // Output JSON to stdout for bridge communication
        std::cout << jsonOutput;
        return 0;
    }

    std::cerr << "{\"status\": \"error\", \"message\": \"Unrecognized command option: " << jsonEscape(mode) << "\"}\n";
    return 1;
}
