# CYBERSHIELD
## Cyberattack Detection and Log Analysis System Using C++

> **Intelligent Rule-Based Security Monitoring and Incident Analysis**  
> *A First-Year University Capstone Project in Systems Programming and Cybersecurity*

---

## 1. Project Title & Overview

**CyberShield** is a comprehensive, functional, and professionally designed Security Operations Centre (SOC) log analysis and threat detection system. Developed primarily in **C++17**, the system ingests, validates, clusters, and analyzes computer and network activity logs to identify suspicious behaviors, detect potential cyberattacks in real time, manage incident lifecycles, and generate downloadable compliance reports.

The project demonstrates high-performance systems programming, object-oriented software engineering, STL container utilization, and temporal sliding-window correlation algorithms.

---

## 2. Problem Statement

Modern enterprise networks generate massive volumes of authentication, access, and service logs daily. Security analysts face significant challenges:
1. **Log Volume Overload:** Manually correlating thousands of disparate log entries across multiple hosts is impossible.
2. **Alert Fatigue & Inaccuracy:** Naive thresholding produces high rates of false positives, eroding trust in automated security systems.
3. **Detection Latency:** Slow or unoptimized log parsers fail to flag ongoing cyberattacks (such as brute-force password guessing or port scans) before damage occurs.
4. **Lack of Lifecycle Tracking:** Detected threats are often lost without a persistent state machine to triage, investigate, and resolve incidents.

CyberShield solves these problems by executing low-latency temporal correlation in native C++, coupled with persistent alert management and an intuitive modern SOC dashboard.

---

## 3. Project Objectives

- **Core C++ Execution:** Implement all log parsing, validation, statistical analysis, threat detection, and alert management algorithms natively in C++17.
- **Four Independent Modular Subsystems:** Cleanly decouple Log Collection, Statistical Analysis, Heuristic Threat Detection, and Alert Management into discrete OOP classes.
- **Accurate Temporal Correlation:** Implement sliding-window algorithms to detect attacks based on configurable count and duration thresholds while eliminating duplicate alerts for the same attack burst.
- **Negative Control / Zero False Positives:** Ensure normal legitimate activity never generates false positive alerts.
- **Persistent Incident Lifecycle:** Maintain alert state transitions (`New` → `Investigating` → `Resolved` / `False Positive`) across application and server restarts.
- **Professional SOC User Interface:** Provide a dark navy dashboard featuring responsive metrics, SVG data visualizations, log inspection tables, and report downloads.

---

## 4. Application Architecture

CyberShield follows a strict unidirectional processing pipeline:

```
[ Log File (.csv / .txt) ]
          │
          ▼
┌────────────────────────────────────────────────────────┐
│               MODULE 1: C++ LOG COLLECTOR              │
│ - Stream tokenization (fstream)                        │
│ - IPv4, timestamp, and port validation                 │
│ - Rejection & error logging of malformed entries       │
└─────────────────────────┬──────────────────────────────┘
                          │ std::vector<LogRecord>
                          ▼
┌────────────────────────────────────────────────────────┐
│               MODULE 2: C++ LOG ANALYZER               │
│ - Event frequency aggregation (std::map)               │
│ - IP clustering & activity ranking                     │
│ - Repeated authentication failure tracking             │
│ - Temporal timeline bucketing                          │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│            MODULE 3: C++ THREAT DETECTOR               │
│ - Sliding time window algorithms                       │
│ - Heuristic Rule 1: Brute-Force Login Detection        │
│ - Heuristic Rule 2: Port Scanning Detection            │
│ - Heuristic Rule 3: Unauthorized Resource Access       │
│ - Heuristic Rule 4: High-Rate Request Flooding         │
│ - Alert deduplication across overlapping spans         │
└─────────────────────────┬──────────────────────────────┘
                          │ std::vector<DetectedThreat>
                          ▼
┌────────────────────────────────────────────────────────┐
│              MODULE 4: C++ ALERT MANAGER               │
│ - Persistent JSON storage (alerts_store.json)          │
│ - SOC analyst state machine (Investigating/Resolved)   │
│ - Comprehensive CSV compliance report generator        │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│          LIGHTWEIGHT BACKEND API BRIDGE (Flask)        │
│ - Invokes compiled C++ engine (cybershield_engine.exe) │
│ - Handles file uploads and static asset delivery       │
│ - NO detection algorithms duplicated in Python         │
└─────────────────────────┬──────────────────────────────┘
                          │ JSON REST API
                          ▼
┌────────────────────────────────────────────────────────┐
│             FRONTEND DASHBOARD (React + Vite)          │
│ - SOC Dark Navy theme                                  │
│ - 7 Interactive modules & responsive SVG charts        │
└────────────────────────────────────────────────────────┘
```

---

## 5. Four Core Project Modules

### Module 1: Log File Collection (`LogCollector.h` / `LogCollector.cpp`)
- Reads raw CSV and TXT files using C++ `std::ifstream`.
- Extracts: `timestamp`, `source_ip`, `username`, `event_type`, `destination_port`, and `status`.
- Validates IPv4 octets, timestamp syntax (`YYYY-MM-DD HH:MM:SS`), and port ranges (1–65535).
- Safely isolates malformed records without throwing exceptions or terminating execution.
- Stores validated records in `std::vector<LogRecord>`.

### Module 2: Log Processing and Analysis (`LogAnalyzer.h` / `LogAnalyzer.cpp`)
- Computes aggregate metrics: total logs, successful logins, failed logins, and distinct IP count.
- Groups events by IP address using `std::map<std::string, std::vector<LogRecord>>`.
- Identifies and ranks the most active IP addresses by event count.
- Flags repeated authentication failures per IP address.
- Computes time-bucketed event timelines for graphical plotting.
- Supports multi-field filtering by IP substring, event type, and Unix epoch bounds.

### Module 3: Cyberattack Detection Engine (`ThreatDetector.h` / `ThreatDetector.cpp`)
- Core heuristic detection engine operating entirely in C++.
- Evaluates sorted timestamps using sliding time-window logic.
- Implements 4 distinct detection rules (detailed in Section 7).
- Automatically suppresses duplicate alerts across overlapping event bursts.
- Generates clear, human-readable explanations detailing event counts, timestamps, and triggered rules.
- Labels findings as *Potential Threats* in alignment with SOC triage standards.

### Module 4: Alert Management and Report Generation (`AlertManager.h` / `AlertManager.cpp`)
- Transforms raw detected threats into persistent security incidents (`SecurityAlert`).
- Assigns unique, sequential alert identifiers (`ALT-0001`, `ALT-0002`).
- Manages SOC analyst triage state transitions: `New` → `Investigating` → `Resolved` / `False Positive`.
- Serializes and deserializes incident data to `alerts_store.json`, preserving status across restarts.
- Generates downloadable CSV security audits containing executive summaries, category breakdowns, and incident logs.

---

## 6. Technologies Used

| Layer | Component | Version / Standard | Purpose |
| :--- | :--- | :--- | :--- |
| **Core Engine** | C++ | C++17 | All log ingestion, parsing, threat detection, and report generation |
| **Compiler** | GCC / MinGW-w64 | 16.2.0 (UCRT64) | Native Windows compilation with static runtime linkage |
| **Backend Bridge** | Python / Flask | 3.13 / Flask 3.1 | Lightweight API bridge to execute compiled C++ binary |
| **Frontend UI** | React.js / Vite | React 18 / Vite 5 | SOC Dashboard with dark theme and dynamic data visualization |
| **Icons & Styling** | Lucide / Custom CSS | Modern CSS | Dark Navy SOC theme, pulsing radar beacons, and badges |

---

## 7. Heuristic Detection Rules

| Attack Category | Trigger Heuristic | Default Window | Severity | Triggered Rule Code |
| :--- | :--- | :--- | :--- | :--- |
| **Brute-Force Login** | $\ge 5$ failed login attempts from same IP | 300 seconds (5 min) | **HIGH** | `RULE_BRUTE_FORCE_01` |
| **Port Scanning** | Connections to $\ge 10$ distinct destination ports | 300 seconds (5 min) | **MEDIUM** | `RULE_PORT_SCAN_02` |
| **Unauthorized Access** | $\ge 5$ denied or restricted resource requests | 300 seconds (5 min) | **HIGH** | `RULE_UNAUTH_ACCESS_03` |
| **Request Flooding** | $\ge 50$ requests from same IP | 60 seconds (1 min) | **HIGH** | `RULE_REQUEST_FLOOD_04` |

*Note: All thresholds, window durations, and severities are configurable via the Settings page or `detection_config.json`.*

---

## 8. Application Navigation (7 Pages)

1. **Dashboard:** High-level executive overview featuring 4 stat cards, attack category bar chart, severity radial donut chart, temporal activity timeline, and recent incidents table.
2. **Log Collection:** Drag-and-drop file uploader, 6 pre-built evaluation datasets with 1-click loading, validation counters, rejected record inspector, and a searchable parsed records table.
3. **Log Analysis:** Deep-dive statistics on successful vs. failed logins, event frequency distribution, repeated login failure watchlist, and ranked active IP tables.
4. **Threat Detection:** Live threats table showing attack category, source IP, trigger timestamp, event counts, severity, and plain-language explanations.
5. **Security Alerts:** Incident management table allowing SOC analysts to filter alerts and update statuses (`New`, `Investigating`, `Resolved`, `False Positive`) with persistent local disk storage.
6. **Reports:** Executive incident breakdown, resolution rate calculations, suspicious source IP rankings, and a one-click CSV report download.
7. **Settings:** SOC configuration interface to customize thresholds, sliding window seconds, and severity levels, affecting the C++ engine immediately upon saving.

---

## 9. Sample Datasets (Included in `/data`)

| Dataset File | Records | Scenario & Intended Detection Result |
| :--- | :--- | :--- |
| `normal_logs.csv` | 120 | Legitimate enterprise activity. **Zero threats flagged (negative control test).** |
| `brute_force_logs.csv` | 115 | Attacker IP `10.0.0.45` attempting rapid failed logins. **Flags Brute-Force Login.** |
| `port_scan_logs.csv` | 125 | Attacker IP `172.16.5.99` scanning 15 ports. **Flags Port Scanning.** |
| `unauthorized_access_logs.csv` | 115 | Attacker IP `198.51.100.24` probing `/admin/secrets`. **Flags Unauthorized Access.** |
| `request_flooding_logs.csv` | 135 | Attacker IP `203.0.113.88` generating 60 requests in 40s. **Flags Request Flooding.** |
| `mixed_logs.csv` | 256 | Multi-vector attack with normal traffic and 2 malformed records. **Flags all 4 attacks.** |

---

## 10. Standalone C++ Compilation & Testing

The C++ engine is 100% self-contained and independently compilable without requiring Node.js, React, or Python.

### Windows Compilation Commands (PowerShell / CMD)
```powershell
# Navigate to cpp_engine directory
cd CyberShield\cpp_engine

# Compile Core CLI Engine
g++ -std=c++17 -O2 -Wall -DEXCLUDE_STANDALONE_MAIN -o cybershield_engine.exe main.cpp LogCollector.cpp LogAnalyzer.cpp ThreatDetector.cpp AlertManager.cpp ..\tests\detection_tests.cpp

# Compile Standalone Verification Test Suite
g++ -std=c++17 -O2 -Wall -o ..\tests\detection_tests.exe ..\tests\detection_tests.cpp LogCollector.cpp LogAnalyzer.cpp ThreatDetector.cpp AlertManager.cpp
```

### Running the Standalone Verification Suite
```powershell
cd CyberShield\tests
.\detection_tests.exe
```

**Verification Suite Output:**
```
========================================================
   CYBERSHIELD STANDALONE C++ CORE VERIFICATION SUITE   
   Academic Capstone Verification & Security Rule Tests 
========================================================

[TEST 1/8] Verifying LogCollector parser and validation logic... [PASSED]
[TEST 2/8] Verifying LogAnalyzer metrics & event distribution... [PASSED]
[TEST 3/8] Verifying Attack 1: Brute-Force Login Detection...    [PASSED]
[TEST 4/8] Verifying Attack 2: Port Scanning Detection...        [PASSED]
[TEST 5/8] Verifying Attack 3: Unauthorized Resource Access...   [PASSED]
[TEST 6/8] Verifying Attack 4: Request Flooding...               [PASSED]
[TEST 7/8] Verifying Normal Activity Baseline (0 False Alerts).. [PASSED]
[TEST 8/8] Verifying AlertManager persistence & transitions...   [PASSED]

========================================================
   TEST RESULTS: 8 / 8 TESTS PASSED (100% SUCCESS)
========================================================
```

---

## 11. Full-Stack Launch Instructions

### Option A: 1-Click Launch (Recommended)
Double-click `start_all.bat` in the project root directory, or run:
```powershell
.\start_all.bat
```
This automatically starts the backend API bridge on port 5000, starts the Vite frontend on port 5173, and opens your default browser.

### Option B: Manual Step-by-Step Launch

**Terminal 1 — Backend Bridge:**
```powershell
cd CyberShield\backend
python app.py
```
*Backend runs on http://localhost:5000*

**Terminal 2 — Frontend Dev Server:**
```powershell
cd CyberShield\frontend
npm run dev
```
*Frontend runs on http://localhost:5173*

---

## 12. Limitations & Future Enhancements

### Current Limitations
- **File Ingestion:** The current implementation parses static and uploaded log files (.csv, .txt) rather than reading live raw packet sockets (e.g. pcap/promiscuous mode).
- **Rule Scope:** Focuses on four primary attack signatures (Brute-Force, Port Scanning, Unauthorized Access, Request Flooding); more complex multi-stage APTs are not covered.
- **Log Format:** Assumes standardized comma-separated column mapping (`timestamp,source_ip,username,event_type,destination_port,status`).

### Future Enhancements
- **Live Syslog UDP Listener:** Integrate a background socket listener in C++ to ingest real-time RFC 5424 syslog streams.
- **Machine Learning Anomaly Detection:** Implement statistical entropy scoring and autoencoder models to detect zero-day anomalies without fixed rules.
- **Automated Firewall Integration:** Automatically execute iptables or Windows Firewall netsh commands upon detecting HIGH severity threats.

---

## 13. Project Structure

```
CyberShield/
├── frontend/                     # React.js + Vite Web Application
│   ├── src/
│   │   ├── pages/
│   │   │   ├── DashboardPage.jsx
│   │   │   ├── LogCollectionPage.jsx
│   │   │   ├── LogAnalysisPage.jsx
│   │   │   ├── ThreatDetectionPage.jsx
│   │   │   ├── SecurityAlertsPage.jsx
│   │   │   ├── ReportsPage.jsx
│   │   │   └── SettingsPage.jsx
│   │   ├── App.jsx
│   │   ├── index.css
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js
│
├── backend/                      # Python Flask API Bridge
│   ├── app.py
│   └── requirements.txt
│
├── cpp_engine/                   # Native C++ Core Engine
│   ├── LogRecord.h
│   ├── LogCollector.h
│   ├── LogCollector.cpp
│   ├── LogAnalyzer.h
│   ├── LogAnalyzer.cpp
│   ├── ThreatDetector.h
│   ├── ThreatDetector.cpp
│   ├── AlertManager.h
│   ├── AlertManager.cpp
│   ├── main.cpp
│   └── CMakeLists.txt
│
├── data/                         # Evaluation Datasets & Persistent Storage
│   ├── normal_logs.csv
│   ├── brute_force_logs.csv
│   ├── port_scan_logs.csv
│   ├── unauthorized_access_logs.csv
│   ├── request_flooding_logs.csv
│   ├── mixed_logs.csv
│   ├── alerts_store.json
│   └── detection_config.json
│
├── reports/                      # Generated CSV Reports
│
├── tests/                        # Standalone C++ & Integration Tests
│   ├── detection_tests.cpp
│   └── test_integration.py
│
├── build_engine.bat              # Windows C++ Compilation Script
├── run_tests.bat                 # Standalone Tests Runner Script
├── start_application.bat         # Full-Stack Application Launcher
├── README.md
└── .gitignore
```
