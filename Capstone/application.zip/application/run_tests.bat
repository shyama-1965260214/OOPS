@echo off
echo ========================================================
echo   CYBERSHIELD: Executing Standalone C++ Tests
echo ========================================================

set "PATH=C:\msys64\ucrt64\bin;%PATH%"
cd /d "%~dp0\tests"

if not exist "detection_tests.exe" (
    echo [!] detection_tests.exe not found. Running build_engine.bat first...
    call "..\build_engine.bat"
)

detection_tests.exe
pause
