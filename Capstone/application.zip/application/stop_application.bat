@echo off
title CyberShield - Stop
color 0C
echo.
echo  [*] Stopping CyberShield services...

for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":5000 " 2^>nul') do (
    taskkill /PID %%a /F >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":5173 " 2^>nul') do (
    taskkill /PID %%a /F >nul 2>&1
)

echo  [*] All CyberShield services stopped.
timeout /t 2 /nobreak >nul
