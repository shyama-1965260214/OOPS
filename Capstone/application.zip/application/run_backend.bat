
@echo off
title CYBERSHIELD BACKEND

cd /d "%~dp0backend"

echo Starting CyberShield Backend...
python app.py

pause
