import os
import sys
import json
import subprocess
from flask import Flask, request, jsonify, send_file, send_from_directory

# Project Root setup
BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BACKEND_DIR)
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
UPLOADS_DIR = os.path.join(DATA_DIR, "uploads")
REPORTS_DIR = os.path.join(PROJECT_ROOT, "reports")
CPP_ENGINE_DIR = os.path.join(PROJECT_ROOT, "cpp_engine")
ALERTS_STORE = os.path.join(DATA_DIR, "alerts_store.json")
CONFIG_FILE = os.path.join(DATA_DIR, "detection_config.json")
ENGINE_EXE = os.path.join(CPP_ENGINE_DIR, "cybershield_engine.exe")

os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)

# Ensure runtime DLLs directory is in PATH so subprocess can invoke C++ engine cleanly
runtime_path = r"C:\msys64\ucrt64\bin"
if runtime_path not in os.environ.get("PATH", ""):
    os.environ["PATH"] = runtime_path + ";" + os.environ.get("PATH", "")

app = Flask(__name__, static_folder=os.path.join(PROJECT_ROOT, "frontend", "dist"), static_url_path="")

# In-memory cache of latest C++ analysis result
latest_analysis_cache = None

# CORS Headers & Pre-flight Handling
@app.before_request
def handle_preflight():
    if request.method == "OPTIONS":
        response = app.make_default_options_response()
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
        return response

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    return response

@app.errorhandler(Exception)
def handle_exception(e):
    return jsonify({"status": "error", "message": str(e)}), 500

def ensure_default_config():
    if not os.path.exists(CONFIG_FILE):
        default_cfg = {
            "bruteForceThreshold": 5,
            "bruteForceWindowSec": 300,
            "bruteForceSeverity": "HIGH",
            "portScanThreshold": 10,
            "portScanWindowSec": 300,
            "portScanSeverity": "MEDIUM",
            "unauthorizedThreshold": 5,
            "unauthorizedWindowSec": 300,
            "unauthorizedSeverity": "HIGH",
            "requestFloodThreshold": 50,
            "requestFloodWindowSec": 60,
            "requestFloodSeverity": "HIGH"
        }
        with open(CONFIG_FILE, "w") as f:
            json.dump(default_cfg, f, indent=2)

ensure_default_config()

def run_cpp_engine(args):
    """Invokes compiled C++ engine binary and returns stdout string."""
    if not os.path.exists(ENGINE_EXE):
        raise FileNotFoundError(f"C++ Engine executable not found at: {ENGINE_EXE}. Please compile it first.")

    cmd = [ENGINE_EXE] + args
    result = subprocess.run(
        cmd,
        cwd=PROJECT_ROOT,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace"
    )

    if result.returncode != 0:
        err_msg = result.stderr.strip() or f"Engine exited with code {result.returncode}"
        raise RuntimeError(f"C++ Engine failed: {err_msg}")

    return result.stdout.strip()

# ----------------- API ROUTES ----------------- #

@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({
        "status": "healthy",
        "service": "CyberShield API Bridge",
        "engine_executable": os.path.exists(ENGINE_EXE),
        "engine_path": ENGINE_EXE
    })

@app.route("/api/samples", methods=["GET"])
def list_samples():
    samples = [
        {
            "id": "mixed_logs.csv",
            "name": "Mixed Attack & Normal Logs",
            "filename": "mixed_logs.csv",
            "description": "Comprehensive SOC scenario containing all 4 attack types (Brute-Force, Port Scanning, Unauthorized Access, Request Flooding) along with normal baseline logs and malformed records for validation.",
            "recordCount": 256
        },
        {
            "id": "normal_logs.csv",
            "name": "Normal Baseline Activity Logs",
            "filename": "normal_logs.csv",
            "description": "Legitimate enterprise employee activities (logins, web traffic, file shares). Used as a negative control to verify zero false positives.",
            "recordCount": 120
        },
        {
            "id": "brute_force_logs.csv",
            "name": "Brute-Force Login Simulation",
            "filename": "brute_force_logs.csv",
            "description": "Attacker IP 10.0.0.45 executing repeated rapid failed SSH/system login attempts against common usernames.",
            "recordCount": 115
        },
        {
            "id": "port_scan_logs.csv",
            "name": "Port Scanning Simulation",
            "filename": "port_scan_logs.csv",
            "description": "Attacker IP 172.16.5.99 probing 15 distinct service ports (SSH, RDP, HTTP, SQL, SMB) within a 3-minute window.",
            "recordCount": 125
        },
        {
            "id": "unauthorized_access_logs.csv",
            "name": "Unauthorized Resource Access Simulation",
            "filename": "unauthorized_access_logs.csv",
            "description": "Attacker IP 198.51.100.24 attempting unauthorized access to privileged endpoints (/admin/secrets, /etc/shadow, DB backups).",
            "recordCount": 115
        },
        {
            "id": "request_flooding_logs.csv",
            "name": "Request Flooding (DoS) Simulation",
            "filename": "request_flooding_logs.csv",
            "description": "Attacker IP 203.0.113.88 sending 60 rapid HTTP requests within 40 seconds to overwhelm API endpoints.",
            "recordCount": 135
        }
    ]
    return jsonify(samples)

@app.route("/api/upload", methods=["POST", "OPTIONS"])
def upload_log_file():
    if request.method == "OPTIONS":
        return jsonify({"status": "ok"}), 200

    # Accept "file" field name, or fallback to any file in request.files
    file = None
    for key in ["file", "logFile", "logfile", "csv", "csvFile", "upload", "data"]:
        if key in request.files:
            file = request.files[key]
            break
    if file is None and len(request.files) > 0:
        file = next(iter(request.files.values()))

    if file is None or file.filename == "":
        return jsonify({"status": "error", "message": "No file uploaded in form-data. Expected multipart form field 'file'."}), 400

    # Sanitize filename and validate extension (.csv or .txt)
    raw_name = os.path.basename(file.filename)
    if not (raw_name.lower().endswith(".csv") or raw_name.lower().endswith(".txt")):
        return jsonify({"status": "error", "message": "Invalid file format. Only .csv and .txt files are supported."}), 400

    filename = raw_name
    save_path = os.path.join(UPLOADS_DIR, filename)
    file.save(save_path)

    # Immediately invoke the C++ engine to parse, validate, and analyze the uploaded logs
    args = [
        "--analyze", save_path,
        "--config", CONFIG_FILE,
        "--store", ALERTS_STORE
    ]

    try:
        raw_output = run_cpp_engine(args)
        json_start = raw_output.find("{")
        if json_start == -1:
            return jsonify({
                "status": "error", 
                "message": "C++ Engine did not return valid JSON output",
                "raw": raw_output[:300]
            }), 500

        parsed_json = json.loads(raw_output[json_start:])
        global latest_analysis_cache
        latest_analysis_cache = parsed_json

        # Attach file metadata
        parsed_json["filePath"] = save_path
        parsed_json["filename"] = filename
        return jsonify(parsed_json)

    except Exception as e:
        return jsonify({
            "status": "error", 
            "message": f"C++ Engine analysis failed on uploaded file: {str(e)}"
        }), 500

@app.route("/api/analyze", methods=["POST"])
def run_analysis():
    global latest_analysis_cache
    data = request.get_json(silent=True) or {}
    file_path = data.get("filePath")

    # If sample name is provided
    sample_name = data.get("sampleName")
    if sample_name:
        file_path = os.path.join(DATA_DIR, sample_name)

    if not file_path or not os.path.exists(file_path):
        return jsonify({"status": "error", "message": f"Log file not found: {file_path}"}), 400

    args = [
        "--analyze", file_path,
        "--config", CONFIG_FILE,
        "--store", ALERTS_STORE
    ]

    try:
        raw_output = run_cpp_engine(args)
        # Parse JSON output from C++ engine
        json_start = raw_output.find("{")
        if json_start == -1:
            return jsonify({"status": "error", "message": "Failed to parse JSON from C++ engine"}), 500

        parsed_json = json.loads(raw_output[json_start:])
        latest_analysis_cache = parsed_json
        return jsonify(parsed_json)

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/dashboard", methods=["GET"])
def get_dashboard():
    global latest_analysis_cache
    try:
        # If no analysis run yet, run analysis on mixed_logs.csv by default so dashboard has live stats
        if latest_analysis_cache is None:
            default_sample = os.path.join(DATA_DIR, "mixed_logs.csv")
            if os.path.exists(default_sample):
                raw_out = run_cpp_engine(["--analyze", default_sample, "--config", CONFIG_FILE, "--store", ALERTS_STORE])
                json_start = raw_out.find("{")
                if json_start != -1:
                    latest_analysis_cache = json.loads(raw_out[json_start:])

        # Fetch latest persistent alerts summary directly from C++ engine
        raw_alerts = run_cpp_engine(["--get-alerts", "--store", ALERTS_STORE])
        alerts_json = json.loads(raw_alerts[raw_alerts.find("{"):])

        dashboard_data = {
            "status": "success",
            "hasAnalysis": latest_analysis_cache is not None,
            "collection": latest_analysis_cache.get("collection", {}) if latest_analysis_cache else {},
            "analysis": latest_analysis_cache.get("analysis", {}) if latest_analysis_cache else {},
            "threats": latest_analysis_cache.get("threats", []) if latest_analysis_cache else [],
            "alerts": alerts_json.get("alerts", []),
            "summary": alerts_json.get("summary", {})
        }
        return jsonify(dashboard_data)

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/threats", methods=["GET"])
def get_threats():
    global latest_analysis_cache
    if latest_analysis_cache and "threats" in latest_analysis_cache:
        return jsonify({
            "status": "success",
            "threats": latest_analysis_cache["threats"]
        })
    return jsonify({
        "status": "success",
        "threats": []
    })

@app.route("/api/alerts", methods=["GET"])
def get_alerts():
    try:
        raw_output = run_cpp_engine(["--get-alerts", "--store", ALERTS_STORE])
        json_start = raw_output.find("{")
        if json_start == -1:
            return jsonify({"status": "error", "message": "Failed to retrieve alerts"}), 500
        return jsonify(json.loads(raw_output[json_start:]))
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/alerts/<alert_id>/status", methods=["POST"])
def update_alert_status(alert_id):
    data = request.get_json(silent=True) or {}
    new_status = data.get("status")

    if not new_status:
        return jsonify({"status": "error", "message": "Missing status parameter"}), 400

    try:
        raw_output = run_cpp_engine(["--update-alert", alert_id, new_status, "--store", ALERTS_STORE])
        json_start = raw_output.find("{")
        if json_start != -1:
            return jsonify(json.loads(raw_output[json_start:]))
        return jsonify({"status": "success", "alertId": alert_id, "newStatus": new_status})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/api/config", methods=["GET"])
def get_config():
    ensure_default_config()
    with open(CONFIG_FILE, "r") as f:
        cfg = json.load(f)
    return jsonify({"status": "success", "config": cfg})

@app.route("/api/config", methods=["POST"])
def update_config():
    data = request.get_json(silent=True) or {}
    ensure_default_config()
    with open(CONFIG_FILE, "r") as f:
        cfg = json.load(f)

    # Update fields with validation
    for key in ["bruteForceThreshold", "bruteForceWindowSec", "portScanThreshold", 
                "portScanWindowSec", "unauthorizedThreshold", "unauthorizedWindowSec",
                "requestFloodThreshold", "requestFloodWindowSec"]:
        if key in data:
            try:
                cfg[key] = int(data[key])
            except ValueError:
                pass

    for key in ["bruteForceSeverity", "portScanSeverity", "unauthorizedSeverity", "requestFloodSeverity"]:
        if key in data:
            cfg[key] = str(data[key]).upper()

    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

    return jsonify({"status": "success", "message": "Detection thresholds updated successfully", "config": cfg})

@app.route("/api/report/download", methods=["GET"])
def download_report():
    report_path = os.path.join(REPORTS_DIR, "CyberShield_Security_Report.csv")
    try:
        run_cpp_engine(["--generate-report", report_path, "--store", ALERTS_STORE])
        if os.path.exists(report_path):
            return send_file(
                report_path,
                mimetype="text/csv",
                as_attachment=True,
                download_name="CyberShield_Security_Report.csv"
            )
        else:
            return jsonify({"status": "error", "message": "Report file not found"}), 404
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# Catch-all for serving React single-page build in production mode
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_frontend(path):
    dist_dir = os.path.join(PROJECT_ROOT, "frontend", "dist")
    if path != "" and os.path.exists(os.path.join(dist_dir, path)):
        return send_from_directory(dist_dir, path)
    if os.path.exists(os.path.join(dist_dir, "index.html")):
        return send_from_directory(dist_dir, "index.html")
    return jsonify({
        "service": "CYBERSHIELD API Bridge",
        "status": "Online",
        "documentation": "Connect via frontend dev server or build frontend to dist."
    })

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"[*] Starting CyberShield Backend Bridge on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=False)
