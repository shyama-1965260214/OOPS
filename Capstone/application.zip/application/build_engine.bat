@echo off
echo ========================================================
echo   CYBERSHIELD: Compiling C++ Core Engine (C++17)
echo ========================================================

set "PATH=C:\msys64\ucrt64\bin;%PATH%"
cd /d "%~dp0\cpp_engine"

echo [*] Compiling cybershield_engine.exe...
g++ -std=c++17 -O2 -Wall -DEXCLUDE_STANDALONE_MAIN -o cybershield_engine.exe main.cpp LogCollector.cpp LogAnalyzer.cpp ThreatDetector.cpp AlertManager.cpp ..\tests\detection_tests.cpp

echo [*] Compiling detection_tests.exe...
g++ -std=c++17 -O2 -Wall -o ..\tests\detection_tests.exe ..\tests\detection_tests.cpp LogCollector.cpp LogAnalyzer.cpp ThreatDetector.cpp AlertManager.cpp

echo [*] Copying runtime DLLs...
copy /y "C:\msys64\ucrt64\bin\libwinpthread-1.dll" "." >nul 2>&1
copy /y "C:\msys64\ucrt64\bin\libgcc_s_seh-1.dll" "." >nul 2>&1
copy /y "C:\msys64\ucrt64\bin\libstdc++-6.dll" "." >nul 2>&1
copy /y "C:\msys64\ucrt64\bin\libwinpthread-1.dll" "..\tests\" >nul 2>&1
copy /y "C:\msys64\ucrt64\bin\libgcc_s_seh-1.dll" "..\tests\" >nul 2>&1
copy /y "C:\msys64\ucrt64\bin\libstdc++-6.dll" "..\tests\" >nul 2>&1

echo [OK] C++ Compilation Complete!
echo Executable located at: %~dp0cpp_engine\cybershield_engine.exe
pause
