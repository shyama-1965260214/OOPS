import React from 'react';
import { 
  ShieldAlert, 
  Activity, 
  AlertTriangle, 
  Flame, 
  FileUp, 
  Search, 
  ShieldCheck, 
  Download,
  ArrowUpRight,
  Clock,
  Server
} from 'lucide-react';

export default function DashboardPage({ 
  dashboardData, 
  onNavigate, 
  onRunAnalysis, 
  onDownloadReport,
  isLoading 
}) {
  const collection = dashboardData?.collection || {};
  const analysis = dashboardData?.analysis || {};
  const threats = dashboardData?.threats || [];
  const alerts = dashboardData?.alerts || [];
  const summary = dashboardData?.summary || {};

  const totalLogs = collection.validRecords || analysis.totalEvents || 0;
  const suspiciousCount = threats.reduce((sum, t) => sum + (t.suspiciousEventCount || 0), 0);
  const totalThreats = summary.totalAlerts !== undefined ? summary.totalAlerts : threats.length;
  const highSeverity = summary.highSeverity || threats.filter(t => t.severity === 'HIGH').length;

  const categoryDistribution = summary.categoryDistribution || {};
  const timeline = analysis.timeline || [];

  // Severity counts
  const highCount = summary.highSeverity || 0;
  const medCount = summary.mediumSeverity || 0;
  const lowCount = summary.lowSeverity || 0;
  const totalSev = highCount + medCount + lowCount || 1;

  // Maximum value for timeline scaling
  const maxTimelineCount = Math.max(...timeline.map(t => t.count), 1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      {/* Top Banner / System Status */}
      <div className="soc-card" style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        background: 'linear-gradient(135deg, rgba(13, 21, 39, 0.9) 0%, rgba(22, 36, 68, 0.8) 100%)',
        borderLeft: '4px solid #38bdf8'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.3rem' }}>
            <span className="pulse-beacon"></span>
            <span style={{ fontSize: '0.8rem', color: '#38bdf8', fontWeight: 600, letterSpacing: '0.05em' }}>
              SECURITY OPERATIONS CENTER &bull; C++ CORE ENGINE ACTIVE
            </span>
          </div>
          <h2 style={{ fontSize: '1.35rem', fontWeight: 700, color: '#f8fafc' }}>
            SOC Monitoring & Incident Dashboard
          </h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginTop: '0.2rem' }}>
            Active file: <span className="font-mono" style={{ color: '#cbd5e1' }}>{collection.filePath || 'mixed_logs.csv'}</span>
            {' '}&bull; {collection.invalidRecords > 0 && <span style={{ color: '#f87171' }}>{collection.invalidRecords} malformed entries rejected safely</span>}
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
          <button 
            className="btn btn-secondary" 
            onClick={() => onNavigate('collection')}
            title="Import or switch log files"
          >
            <FileUp size={16} /> Import Logs
          </button>
          <button 
            className="btn btn-primary" 
            onClick={onRunAnalysis}
            disabled={isLoading}
            title="Trigger C++ Threat Detection Engine"
          >
            <Search size={16} /> {isLoading ? 'Analyzing...' : 'Run Threat Analysis'}
          </button>
          <button 
            className="btn btn-secondary" 
            onClick={() => onNavigate('alerts')}
            title="Review active security alerts"
          >
            <ShieldAlert size={16} /> View Alerts ({totalThreats})
          </button>
          <button 
            className="btn btn-success" 
            onClick={onDownloadReport}
            title="Download CSV Incident Report"
          >
            <Download size={16} /> Generate Report
          </button>
        </div>
      </div>

      {/* 4 Core Statistics Cards */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', 
        gap: '1.2rem' 
      }}>
        {/* Card 1: Total Logs */}
        <div className="soc-card" style={{ borderTop: '3px solid #38bdf8' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#94a3b8', fontSize: '0.85rem' }}>
            <span>Total Logs Analysed</span>
            <Activity size={18} color="#38bdf8" />
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#f8fafc', marginTop: '0.5rem' }}>
            {totalLogs.toLocaleString()}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.35rem' }}>
            Processed via C++ LogCollector
          </div>
        </div>

        {/* Card 2: Suspicious Activities */}
        <div className="soc-card" style={{ borderTop: '3px solid #f59e0b' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#94a3b8', fontSize: '0.85rem' }}>
            <span>Suspicious Activities</span>
            <AlertTriangle size={18} color="#f59e0b" />
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#fbbf24', marginTop: '0.5rem' }}>
            {suspiciousCount.toLocaleString()}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.35rem' }}>
            Events flagged within time windows
          </div>
        </div>

        {/* Card 3: Total Threats Detected */}
        <div className="soc-card" style={{ borderTop: '3px solid #6366f1' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#94a3b8', fontSize: '0.85rem' }}>
            <span>Total Threats Detected</span>
            <ShieldAlert size={18} color="#818cf8" />
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#c7d2fe', marginTop: '0.5rem' }}>
            {totalThreats}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.35rem' }}>
            Across 4 core detection rules
          </div>
        </div>

        {/* Card 4: High Severity Alerts */}
        <div className="soc-card" style={{ borderTop: '3px solid #ef4444' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#94a3b8', fontSize: '0.85rem' }}>
            <span>High Severity Alerts</span>
            <Flame size={18} color="#ef4444" />
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#f87171', marginTop: '0.5rem' }}>
            {highSeverity}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.35rem' }}>
            Requires immediate investigation
          </div>
        </div>
      </div>

      {/* Row 2: Charts Grid */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', 
        gap: '1.2rem' 
      }}>
        
        {/* Chart 1: Attack Category Distribution */}
        <div className="soc-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.2rem' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Attack Distribution by Category
            </h3>
            <span style={{ fontSize: '0.75rem', color: '#64748b' }}>C++ ThreatDetector</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
            {[
              { label: 'Brute-Force Login', count: categoryDistribution['Brute-Force Login'] || 0, color: '#ef4444' },
              { label: 'Port Scanning', count: categoryDistribution['Port Scanning'] || 0, color: '#f59e0b' },
              { label: 'Unauthorized Resource Access', count: categoryDistribution['Unauthorized Resource Access'] || 0, color: '#ec4899' },
              { label: 'Request Flooding', count: categoryDistribution['Request Flooding'] || 0, color: '#38bdf8' }
            ].map(cat => {
              const maxCat = Math.max(...Object.values(categoryDistribution), 1);
              const pct = Math.round((cat.count / maxCat) * 100);
              return (
                <div key={cat.label}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.3rem' }}>
                    <span style={{ color: '#cbd5e1' }}>{cat.label}</span>
                    <span style={{ fontWeight: 600, color: cat.color }}>{cat.count} incidents</span>
                  </div>
                  <div style={{ width: '100%', height: '8px', background: '#091021', borderRadius: '4px', overflow: 'hidden' }}>
                    <div style={{ 
                      width: `${cat.count > 0 ? Math.max(pct, 8) : 0}%`, 
                      height: '100%', 
                      background: cat.color,
                      borderRadius: '4px',
                      transition: 'width 0.4s ease'
                    }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 2: Severity Distribution Donut / Radial */}
        <div className="soc-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Threat Severity Distribution
            </h3>
            <span style={{ fontSize: '0.75rem', color: '#64748b' }}>Risk Profile</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-around', height: '140px' }}>
            {/* SVG Donut Chart */}
            <div style={{ position: 'relative', width: '120px', height: '120px' }}>
              <svg viewBox="0 0 36 36" style={{ width: '100%', height: '100%', transform: 'rotate(-90deg)' }}>
                {/* Background Ring */}
                <circle cx="18" cy="18" r="14" fill="none" stroke="#091021" strokeWidth="4" />
                {/* High Slice */}
                <circle cx="18" cy="18" r="14" fill="none" stroke="#ef4444" strokeWidth="4"
                  strokeDasharray={`${(highCount / totalSev) * 88} 88`} strokeDashoffset="0" />
                {/* Medium Slice */}
                <circle cx="18" cy="18" r="14" fill="none" stroke="#f59e0b" strokeWidth="4"
                  strokeDasharray={`${(medCount / totalSev) * 88} 88`} strokeDashoffset={`${-(highCount / totalSev) * 88}`} />
                {/* Low Slice */}
                <circle cx="18" cy="18" r="14" fill="none" stroke="#10b981" strokeWidth="4"
                  strokeDasharray={`${(lowCount / totalSev) * 88} 88`} strokeDashoffset={`${-((highCount + medCount) / totalSev) * 88}`} />
              </svg>
              <div style={{ 
                position: 'absolute', 
                top: 0, left: 0, right: 0, bottom: 0, 
                display: 'flex', flexDirection: 'column', 
                alignItems: 'center', justifyContent: 'center' 
              }}>
                <span style={{ fontSize: '1.2rem', fontWeight: 800, color: '#f8fafc' }}>{totalThreats}</span>
                <span style={{ fontSize: '0.65rem', color: '#94a3b8' }}>ALERTS</span>
              </div>
            </div>

            {/* Legend */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', fontSize: '0.8rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#ef4444' }}></span>
                <span style={{ color: '#cbd5e1' }}>High Severity:</span>
                <span style={{ fontWeight: 700, color: '#f87171' }}>{highCount}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#f59e0b' }}></span>
                <span style={{ color: '#cbd5e1' }}>Medium Severity:</span>
                <span style={{ fontWeight: 700, color: '#fbbf24' }}>{medCount}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <span style={{ width: '10px', height: '10px', borderRadius: '50%', background: '#10b981' }}></span>
                <span style={{ color: '#cbd5e1' }}>Low / Normal:</span>
                <span style={{ fontWeight: 700, color: '#34d399' }}>{lowCount}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Security Events Timeline */}
      <div className="soc-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <div>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Security Events Timeline
            </h3>
            <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
              Event frequency bucketed over time intervals
            </p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.75rem', color: '#94a3b8' }}>
            <Clock size={14} /> Real Log Intervals
          </div>
        </div>

        {timeline.length > 0 ? (
          <div style={{ height: '130px', display: 'flex', alignItems: 'flex-end', gap: '8px', paddingBottom: '1.2rem', paddingTop: '0.5rem' }}>
            {timeline.map((bucket, idx) => {
              const heightPct = Math.round((bucket.count / maxTimelineCount) * 100);
              return (
                <div key={idx} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end' }}>
                  <div 
                    title={`${bucket.timeLabel}: ${bucket.count} events`}
                    style={{ 
                      width: '100%', 
                      height: `${Math.max(heightPct, 8)}%`, 
                      background: 'linear-gradient(180deg, #38bdf8 0%, #1e40af 100%)',
                      borderRadius: '3px 3px 0 0',
                      transition: 'height 0.3s'
                    }} 
                  />
                  <span style={{ fontSize: '0.65rem', color: '#64748b', marginTop: '0.35rem', whiteSpace: 'nowrap' }}>
                    {bucket.timeLabel}
                  </span>
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ padding: '2rem', textAlign: 'center', color: '#64748b', fontSize: '0.85rem' }}>
            No timeline activity available. Import and analyze a log file to visualize events.
          </div>
        )}
      </div>

      {/* Row 4: Recent Security Incidents Table */}
      <div className="soc-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ 
          padding: '1rem 1.25rem', 
          borderBottom: '1px solid var(--border-color)', 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center' 
        }}>
          <div>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Recent Security Incidents
            </h3>
            <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
              Live alerts tracked by the C++ engine
            </p>
          </div>
          <button 
            className="btn btn-secondary" 
            style={{ fontSize: '0.75rem', padding: '0.35rem 0.75rem' }}
            onClick={() => onNavigate('alerts')}
          >
            Manage All Incidents <ArrowUpRight size={14} />
          </button>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="soc-table">
            <thead>
              <tr>
                <th>Alert ID</th>
                <th>Category</th>
                <th>Source IP</th>
                <th>Timestamp</th>
                <th>Events</th>
                <th>Severity</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {alerts.length > 0 ? (
                alerts.slice(0, 5).map(alert => (
                  <tr key={alert.alertId}>
                    <td className="font-mono" style={{ color: '#38bdf8', fontWeight: 600 }}>{alert.alertId}</td>
                    <td>{alert.attackCategory}</td>
                    <td className="font-mono">{alert.sourceIp}</td>
                    <td className="font-mono" style={{ fontSize: '0.8rem', color: '#94a3b8' }}>{alert.timestamp}</td>
                    <td style={{ fontWeight: 600 }}>{alert.suspiciousEventCount}</td>
                    <td>
                      <span className={`badge ${alert.severity === 'HIGH' ? 'badge-high' : alert.severity === 'MEDIUM' ? 'badge-medium' : 'badge-low'}`}>
                        {alert.severity}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${
                        alert.status === 'Resolved' ? 'badge-resolved' :
                        alert.status === 'Investigating' ? 'badge-investigating' :
                        alert.status === 'False Positive' ? 'badge-falsepos' : 'badge-new'
                      }`}>
                        {alert.status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '2rem', color: '#64748b' }}>
                    No alerts currently recorded. Click "Import Logs" or load a sample dataset to detect threats.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
