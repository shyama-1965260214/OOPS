import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Search, 
  Filter, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  XCircle, 
  HelpCircle,
  Save,
  RotateCw
} from 'lucide-react';

export default function SecurityAlertsPage({ 
  alerts, 
  onUpdateStatus, 
  onRefreshAlerts,
  isUpdating 
}) {
  const [searchKeyword, setSearchKeyword] = useState('');
  const [severityFilter, setSeverityFilter] = useState('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Filter alerts
  const filteredAlerts = alerts.filter(alert => {
    const text = `${alert.alertId} ${alert.attackCategory} ${alert.sourceIp} ${alert.explanation}`.toLowerCase();
    const matchesSearch = text.includes(searchKeyword.toLowerCase());
    const matchesSeverity = severityFilter === 'ALL' || alert.severity === severityFilter;
    const matchesCategory = categoryFilter === 'ALL' || alert.attackCategory === categoryFilter;
    const matchesStatus = statusFilter === 'ALL' || alert.status === statusFilter;

    return matchesSearch && matchesSeverity && matchesCategory && matchesStatus;
  });

  const categories = ['ALL', ...Array.from(new Set(alerts.map(a => a.attackCategory))).filter(Boolean)];
  const severities = ['ALL', 'HIGH', 'MEDIUM', 'LOW'];
  const statuses = ['ALL', 'New', 'Investigating', 'Resolved', 'False Positive'];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.35rem', fontWeight: 700, color: '#f8fafc' }}>
            Module 4: Security Incident & Alert Management
          </h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginTop: '0.2rem' }}>
            Persistent incident tracking, analyst triage workflow, and incident state management managed by C++ AlertManager.
          </p>
        </div>

        <button 
          className="btn btn-secondary" 
          onClick={onRefreshAlerts}
          title="Reload alerts from disk"
        >
          <RotateCw size={15} /> Refresh Stored Incidents
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="soc-card" style={{ display: 'flex', flexWrap: 'wrap', gap: '0.8rem', alignItems: 'center', justifyContent: 'space-between' }}>
        {/* Search */}
        <div style={{ position: 'relative', flex: '1 1 240px' }}>
          <input 
            type="text" 
            className="soc-input" 
            placeholder="Search by ID, IP, category, or detail..." 
            value={searchKeyword}
            onChange={e => setSearchKeyword(e.target.value)}
            style={{ paddingLeft: '2rem', width: '100%' }}
          />
          <Search size={14} style={{ position: 'absolute', left: '0.7rem', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
        </div>

        {/* Dropdowns */}
        <div style={{ display: 'flex', gap: '0.6rem', flexWrap: 'wrap' }}>
          <select 
            className="soc-select" 
            value={severityFilter} 
            onChange={e => setSeverityFilter(e.target.value)}
          >
            {severities.map(s => <option key={s} value={s}>{s === 'ALL' ? 'All Severities' : `${s} Severity`}</option>)}
          </select>

          <select 
            className="soc-select" 
            value={categoryFilter} 
            onChange={e => setCategoryFilter(e.target.value)}
          >
            {categories.map(c => <option key={c} value={c}>{c === 'ALL' ? 'All Categories' : c}</option>)}
          </select>

          <select 
            className="soc-select" 
            value={statusFilter} 
            onChange={e => setStatusFilter(e.target.value)}
          >
            {statuses.map(st => <option key={st} value={st}>{st === 'ALL' ? 'All Incident Statuses' : st}</option>)}
          </select>
        </div>
      </div>

      {/* Incidents Table */}
      <div className="soc-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Persistent Security Incidents ({filteredAlerts.length} / {alerts.length})
            </h3>
            <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
              Status updates are saved persistently to disk in <span className="font-mono">alerts_store.json</span>
            </p>
          </div>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="soc-table">
            <thead>
              <tr>
                <th>Alert ID</th>
                <th>Category</th>
                <th>Source IP</th>
                <th>Detection Time</th>
                <th>Events</th>
                <th>Severity</th>
                <th>Current Status</th>
                <th>Triage Action (Update Status)</th>
              </tr>
            </thead>
            <tbody>
              {filteredAlerts.length > 0 ? (
                filteredAlerts.map(alert => (
                  <tr key={alert.alertId}>
                    <td className="font-mono" style={{ color: '#38bdf8', fontWeight: 600 }}>{alert.alertId}</td>
                    <td>
                      <div style={{ fontWeight: 600, color: '#f1f5f9' }}>{alert.attackCategory}</div>
                      <div className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>{alert.ruleTriggered}</div>
                    </td>
                    <td className="font-mono" style={{ color: '#fbbf24' }}>{alert.sourceIp}</td>
                    <td className="font-mono" style={{ fontSize: '0.8rem', color: '#94a3b8' }}>{alert.timestamp}</td>
                    <td style={{ fontWeight: 600 }}>{alert.suspiciousEventCount}</td>
                    <td>
                      <span className={`badge ${alert.severity === 'HIGH' ? 'badge-high' : alert.severity === 'MEDIUM' ? 'badge-medium' : 'badge-low'}`}>
                        {alert.severity}
                      </span>
                    </td>
                    <td>
                      <span className={`badge ${
                        alert.status === 'Resolved' ? 'badge-resolved' :
                        alert.status === 'Investigating' ? 'badge-investigating' :
                        alert.status === 'False Positive' ? 'badge-falsepos' : 'badge-new'
                      }`}>
                        {alert.status}
                      </span>
                    </td>
                    <td>
                      {/* Action selector */}
                      <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                        <select 
                          className="soc-select"
                          value={alert.status}
                          disabled={isUpdating}
                          onChange={(e) => onUpdateStatus(alert.alertId, e.target.value)}
                          style={{ fontSize: '0.75rem', padding: '0.35rem 0.5rem' }}
                        >
                          <option value="New">New</option>
                          <option value="Investigating">Investigating</option>
                          <option value="Resolved">Resolved</option>
                          <option value="False Positive">False Positive</option>
                        </select>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '3rem 1rem', color: '#64748b' }}>
                    No security incidents match the current search or filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
