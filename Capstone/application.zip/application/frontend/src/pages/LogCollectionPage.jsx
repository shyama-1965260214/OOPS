import React, { useState } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle2,
  AlertCircle,
  Search,
  Play,
  ShieldAlert,
  Scan,
  Zap,
  Layers,
  ChevronDown,
  ChevronUp,
  Database,
  Loader2
} from 'lucide-react';

// ── 3 Hardcoded demo scenarios (no upload needed) ──────────────────────────
const DEMO_SCENARIOS = [
  {
    id: 'brute_force_logs.csv',
    icon: ShieldAlert,
    iconColor: '#f87171',
    badgeColor: '#ef4444',
    badge: 'HIGH',
    title: 'Scenario 1 — Brute-Force Login Attack',
    description:
      'Attacker IP 10.0.0.45 fires rapid repeated SSH login attempts against common usernames (admin, root, user). Triggers the Brute-Force rule after ≥5 failures within a 5-minute window.',
    records: 115,
    threats: 2,
    tags: ['LOGIN_FAILED', 'SSH', '5-min window'],
  },
  {
    id: 'port_scan_logs.csv',
    icon: Scan,
    iconColor: '#fb923c',
    badgeColor: '#f97316',
    badge: 'MEDIUM',
    title: 'Scenario 2 — Port Scanning Detection',
    description:
      'Attacker IP 172.16.5.99 probes 15 distinct service ports (SSH:22, RDP:3389, HTTP:80, SQL:1433, SMB:445…) within a 3-minute window. Triggers the Port-Scan rule after ≥10 unique ports.',
    records: 125,
    threats: 1,
    tags: ['PORT_CONNECT', 'Multi-port', '3-min window'],
  },
  {
    id: 'mixed_logs.csv',
    icon: Layers,
    iconColor: '#a78bfa',
    badgeColor: '#8b5cf6',
    badge: 'ALL',
    title: 'Scenario 3 — Full SOC Mixed Attack Simulation',
    description:
      'Comprehensive dataset combining all 4 attack types: Brute-Force, Port Scanning, Unauthorized Resource Access, and Request Flooding — alongside clean baseline traffic and intentional malformed records for C++ validation testing.',
    records: 256,
    threats: 6,
    tags: ['Mixed', 'All 4 attacks', 'Malformed rows'],
  },
];

export default function LogCollectionPage({
  collectionData,
  samples,
  onLoadSample,
  onFileUpload,
  isLoading,
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEventType, setSelectedEventType] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [showErrorDrawer, setShowErrorDrawer] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [activeScenario, setActiveScenario] = useState(null);

  const totalLines   = collectionData?.totalLines   || 0;
  const validRecords = collectionData?.validRecords  || 0;
  const invalidRecords = collectionData?.invalidRecords || 0;
  const records = collectionData?.records || [];
  const errors  = collectionData?.errors  || [];
  const activeFile = collectionData?.filePath || null;

  const eventTypes = ['ALL', ...Array.from(new Set(records.map(r => r.eventType))).filter(Boolean)];
  const statuses   = ['ALL', ...Array.from(new Set(records.map(r => r.status))).filter(Boolean)];

  const filteredRecords = records.filter(r => {
    const q = searchQuery.toLowerCase();
    const matchSearch =
      r.sourceIp.toLowerCase().includes(q) ||
      r.username.toLowerCase().includes(q)  ||
      r.eventType.toLowerCase().includes(q) ||
      r.timestamp.toLowerCase().includes(q);
    const matchEvent  = selectedEventType === 'ALL' || r.eventType === selectedEventType;
    const matchStatus = selectedStatus    === 'ALL' || r.status    === selectedStatus;
    return matchSearch && matchEvent && matchStatus;
  });

  // Drag-drop handlers
  const handleDrag = e => {
    e.preventDefault(); e.stopPropagation();
    setDragActive(e.type === 'dragenter' || e.type === 'dragover');
  };
  const handleDrop = e => {
    e.preventDefault(); e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files?.[0]) onFileUpload(e.dataTransfer.files[0]);
  };
  const handleFileInput = e => {
    if (e.target.files?.[0]) onFileUpload(e.target.files[0]);
  };

  // Run a demo scenario
  const handleScenario = async (scenarioId, idx) => {
    setActiveScenario(idx);
    await onLoadSample(scenarioId);
    setActiveScenario(null);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>

      {/* ── Page Header ─────────────────────────────────────── */}
      <div>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 700, color: '#f8fafc' }}>
          Module 1: Log File Collection &amp; Ingestion
        </h2>
        <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginTop: '0.2rem' }}>
          Import, parse, and validate system and security activity logs through the C++ LogCollector engine.
        </p>
      </div>

      {/* ── 3 Demo Scenario Cards ───────────────────────────── */}
      <div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '1rem' }}>
          <Database size={18} color="#38bdf8" />
          <h3 style={{ fontSize: '1rem', fontWeight: 700, color: '#e2e8f0' }}>
            Pre-Loaded Demo Scenarios
          </h3>
          <span style={{
            fontSize: '0.7rem', background: 'rgba(56,189,248,0.15)',
            color: '#38bdf8', padding: '0.15rem 0.55rem', borderRadius: '999px', fontWeight: 600
          }}>
            1-CLICK C++ ANALYSIS
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
          {DEMO_SCENARIOS.map((s, idx) => {
            const Icon = s.icon;
            const isRunning = isLoading && activeScenario === idx;
            const isActive  = activeFile && activeFile.includes(s.id);

            return (
              <div
                key={s.id}
                className="soc-card"
                style={{
                  border: isActive ? `1.5px solid ${s.badgeColor}` : '1px solid var(--border-color)',
                  background: isActive ? `rgba(${s.badgeColor === '#ef4444' ? '239,68,68' : s.badgeColor === '#f97316' ? '249,115,22' : '139,92,246'},0.07)` : 'var(--bg-card)',
                  transition: 'all 0.2s',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.9rem',
                  padding: '1.25rem',
                }}
              >
                {/* Card Top Row */}
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '0.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                    <div style={{
                      background: `rgba(${s.iconColor === '#f87171' ? '248,113,113' : s.iconColor === '#fb923c' ? '251,146,60' : '167,139,250'},0.15)`,
                      borderRadius: '8px', padding: '0.5rem',
                    }}>
                      <Icon size={22} color={s.iconColor} />
                    </div>
                    <div>
                      <span style={{
                        fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.08em',
                        background: s.badgeColor, color: '#fff',
                        padding: '0.1rem 0.5rem', borderRadius: '4px'
                      }}>
                        {s.badge}
                      </span>
                    </div>
                  </div>
                  {isActive && (
                    <span style={{ fontSize: '0.7rem', color: '#34d399', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                      <CheckCircle2 size={13} /> Active
                    </span>
                  )}
                </div>

                {/* Title + Description */}
                <div>
                  <h4 style={{ fontSize: '0.9rem', fontWeight: 700, color: '#e2e8f0', marginBottom: '0.4rem' }}>
                    {s.title}
                  </h4>
                  <p style={{ fontSize: '0.78rem', color: '#94a3b8', lineHeight: 1.5 }}>
                    {s.description}
                  </p>
                </div>

                {/* Stats Row */}
                <div style={{ display: 'flex', gap: '1rem' }}>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#38bdf8' }}>{s.records}</div>
                    <div style={{ fontSize: '0.68rem', color: '#64748b' }}>Log Records</div>
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f87171' }}>{s.threats}</div>
                    <div style={{ fontSize: '0.68rem', color: '#64748b' }}>Threats</div>
                  </div>
                  <div style={{ display: 'flex', gap: '0.35rem', flexWrap: 'wrap', alignItems: 'center', flex: 1 }}>
                    {s.tags.map(t => (
                      <span key={t} style={{
                        fontSize: '0.65rem', background: 'rgba(100,116,139,0.2)',
                        color: '#94a3b8', padding: '0.1rem 0.4rem', borderRadius: '4px', fontFamily: 'monospace'
                      }}>{t}</span>
                    ))}
                  </div>
                </div>

                {/* Load Button */}
                <button
                  className="btn btn-primary"
                  style={{ width: '100%', justifyContent: 'center', fontSize: '0.85rem', padding: '0.55rem' }}
                  onClick={() => handleScenario(s.id, idx)}
                  disabled={isLoading}
                >
                  {isRunning ? (
                    <><Loader2 size={15} className="animate-spin" /> Running C++ Engine...</>
                  ) : (
                    <><Play size={15} /> Load &amp; Analyse in C++</>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Ingestion Summary + Upload Zone ─────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.2rem' }}>

        {/* Upload Card */}
        <div
          className="soc-card"
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          style={{
            border: dragActive ? '2px dashed #38bdf8' : '1px dashed var(--border-color)',
            background: dragActive ? 'rgba(56,189,248,0.08)' : 'var(--bg-card)',
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            textAlign: 'center', padding: '1.8rem 1.5rem', cursor: 'pointer',
          }}
          onClick={() => document.getElementById('log-file-input').click()}
        >
          <input
            type="file"
            id="log-file-input"
            accept=".csv,.txt"
            style={{ display: 'none' }}
            onChange={handleFileInput}
          />
          <UploadCloud size={36} color="#38bdf8" style={{ marginBottom: '0.7rem' }} />
          <h4 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>Upload Your Own Log File</h4>
          <p style={{ fontSize: '0.78rem', color: '#94a3b8', margin: '0.35rem 0 0.9rem', maxWidth: '280px' }}>
            Drag &amp; drop a CSV or TXT file, or click to browse. The C++ engine will parse and validate it instantly.
          </p>
          <button className="btn btn-secondary" style={{ pointerEvents: 'none', fontSize: '0.82rem' }}>
            <FileText size={15} /> Select CSV / TXT File
          </button>
          <span style={{ fontSize: '0.68rem', color: '#64748b', marginTop: '0.5rem' }}>
            Format: timestamp, source_ip, username, event_type, destination_port, status
          </span>
        </div>

        {/* C++ Ingestion Summary Card */}
        <div className="soc-card" style={{ padding: '1.25rem' }}>
          <h3 style={{ fontSize: '0.95rem', fontWeight: 700, color: '#e2e8f0', marginBottom: '1rem' }}>
            C++ Ingestion &amp; Validation Summary
          </h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            {[
              { label: 'Active Source File', value: activeFile ? activeFile.split('\\').pop().split('/').pop() : 'No file loaded', color: activeFile ? '#38bdf8' : '#64748b' },
              { label: 'Total Lines Read',      value: totalLines,     color: '#e2e8f0' },
              { label: 'Valid Records Stored',  value: validRecords,   color: '#34d399' },
              { label: 'Invalid Records Rejected', value: invalidRecords, color: invalidRecords > 0 ? '#f87171' : '#64748b' },
            ].map(item => (
              <div key={item.label} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                paddingBottom: '0.6rem', borderBottom: '1px solid rgba(100,116,139,0.15)'
              }}>
                <span style={{ fontSize: '0.82rem', color: '#94a3b8' }}>{item.label}</span>
                <span style={{ fontSize: '0.88rem', fontWeight: 700, color: item.color, fontFamily: 'monospace' }}>
                  {item.value}
                </span>
              </div>
            ))}
          </div>

          {/* Error Drawer */}
          {invalidRecords > 0 && (
            <div style={{ marginTop: '0.9rem' }}>
              <button
                className="btn btn-secondary"
                style={{ width: '100%', fontSize: '0.8rem' }}
                onClick={() => setShowErrorDrawer(!showErrorDrawer)}
              >
                <AlertCircle size={14} color="#f87171" />
                {showErrorDrawer ? 'Hide' : 'Show'} {invalidRecords} Invalid Records
                {showErrorDrawer ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              </button>
              {showErrorDrawer && errors.length > 0 && (
                <div style={{
                  marginTop: '0.6rem', maxHeight: '140px', overflowY: 'auto',
                  background: 'rgba(239,68,68,0.06)', borderRadius: '6px', padding: '0.6rem'
                }}>
                  {errors.map((e, i) => (
                    <div key={i} style={{ fontSize: '0.72rem', color: '#fca5a5', fontFamily: 'monospace', marginBottom: '0.3rem' }}>
                      Line {e.line}: {e.reason}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Parsed Records Table ─────────────────────────────── */}
      <div className="soc-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{
          padding: '1rem 1.25rem',
          borderBottom: '1px solid var(--border-color)',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          flexWrap: 'wrap', gap: '0.8rem'
        }}>
          <div>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Validated Records ({filteredRecords.length} / {records.length})
            </h3>
            <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
              Stored in C++ <span className="font-mono">std::vector&lt;LogRecord&gt;</span>
            </p>
          </div>

          <div style={{ display: 'flex', gap: '0.6rem', alignItems: 'center', flexWrap: 'wrap' }}>
            <div style={{ position: 'relative' }}>
              <input
                type="text"
                className="soc-input"
                placeholder="Search IP, user, type..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                style={{ paddingLeft: '2rem', width: '200px' }}
              />
              <Search size={14} style={{ position: 'absolute', left: '0.7rem', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
            </div>

            <select className="soc-select" value={selectedEventType} onChange={e => setSelectedEventType(e.target.value)}>
              {eventTypes.map(t => <option key={t} value={t}>{t === 'ALL' ? 'All Event Types' : t}</option>)}
            </select>

            <select className="soc-select" value={selectedStatus} onChange={e => setSelectedStatus(e.target.value)}>
              {statuses.map(s => <option key={s} value={s}>{s === 'ALL' ? 'All Statuses' : s}</option>)}
            </select>
          </div>
        </div>

        <div style={{ maxHeight: '420px', overflowY: 'auto' }}>
          <table className="soc-table">
            <thead style={{ position: 'sticky', top: 0, zIndex: 10 }}>
              <tr>
                <th>#</th>
                <th>Timestamp</th>
                <th>Source IP</th>
                <th>Username</th>
                <th>Event Type</th>
                <th>Dest Port</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredRecords.length > 0 ? (
                filteredRecords.map(r => (
                  <tr key={r.id}>
                    <td className="font-mono" style={{ color: '#64748b' }}>{r.id}</td>
                    <td className="font-mono" style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>{r.timestamp}</td>
                    <td className="font-mono" style={{ color: '#38bdf8' }}>{r.sourceIp}</td>
                    <td>{r.username || '<empty>'}</td>
                    <td>
                      <span className="font-mono" style={{
                        fontSize: '0.8rem',
                        color: (r.eventType.includes('LOGIN_FAILED') || r.eventType.includes('DENIED')) ? '#f87171' : '#cbd5e1'
                      }}>
                        {r.eventType}
                      </span>
                    </td>
                    <td className="font-mono" style={{ color: r.destinationPort > 0 ? '#fbbf24' : '#64748b' }}>
                      {r.destinationPort > 0 ? r.destinationPort : '-'}
                    </td>
                    <td>
                      <span className={`badge ${
                        r.status === 'SUCCESS'                  ? 'badge-normal' :
                        r.status === 'FAILED' || r.status === 'DENIED' ? 'badge-high' : 'badge-new'
                      }`}>
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '2.5rem', color: '#64748b' }}>
                    {records.length === 0
                      ? '👆  Click one of the demo scenarios above to load data into the C++ engine.'
                      : 'No matching records. Try clearing the search filters.'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
