import React from 'react';
import { 
  FileText, 
  Download, 
  ShieldCheck, 
  ShieldAlert, 
  AlertTriangle, 
  PieChart, 
  Users, 
  CheckCircle2,
  Clock,
  Printer
} from 'lucide-react';

export default function ReportsPage({ 
  summary, 
  analysis, 
  onDownloadReport, 
  isDownloading 
}) {
  const totalThreats = summary?.totalAlerts || 0;
  const highSev = summary?.highSeverity || 0;
  const medSev = summary?.mediumSeverity || 0;
  const lowSev = summary?.lowSeverity || 0;

  const resolved = summary?.resolvedCount || 0;
  const investigating = summary?.investigatingCount || 0;
  const newIncidents = summary?.newCount || 0;
  const falsePositives = summary?.falsePositiveCount || 0;
  const unresolved = totalThreats - resolved - falsePositives;

  const categoryDistribution = summary?.categoryDistribution || {};
  const suspiciousIps = summary?.suspiciousIps || {};

  const handlePrint = () => {
    window.print();
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      {/* Header with Export Action */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.35rem', fontWeight: 700, color: '#f8fafc' }}>
            Module 4: Security Incident Reports & Compliance Export
          </h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginTop: '0.2rem' }}>
            Comprehensive SOC report generated directly from C++ AlertManager persistence store.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.6rem' }}>
          <button 
            className="btn btn-secondary" 
            onClick={handlePrint}
          >
            <Printer size={16} /> Print / Save PDF
          </button>
          <button 
            className="btn btn-primary" 
            onClick={onDownloadReport}
            disabled={isDownloading}
            style={{ padding: '0.65rem 1.25rem' }}
          >
            <Download size={16} /> {isDownloading ? 'Generating CSV...' : 'Download Full CSV Report'}
          </button>
        </div>
      </div>

      {/* Executive Summary Card */}
      <div className="soc-card" style={{ borderLeft: '4px solid #38bdf8' }}>
        <h3 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#f8fafc', marginBottom: '0.4rem' }}>
          Executive Security Posture Summary
        </h3>
        <p style={{ fontSize: '0.85rem', color: '#94a3b8', lineHeight: '1.5', maxWidth: '800px' }}>
          This security audit report provides an objective breakdown of anomalous activity, attempted intrusions, and rate-limiting violations observed across monitored endpoints. The findings below reflect real-time heuristic evaluations conducted by the CyberShield C++ Core Engine.
        </p>

        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', 
          gap: '1rem', 
          marginTop: '1.2rem',
          paddingTop: '1.2rem',
          borderTop: '1px solid #1e293b'
        }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Total Incidents Logged</div>
            <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#f8fafc', marginTop: '0.2rem' }}>
              {totalThreats}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Resolved Incidents</div>
            <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#34d399', marginTop: '0.2rem' }}>
              {resolved}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Active / Unresolved</div>
            <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#f87171', marginTop: '0.2rem' }}>
              {unresolved}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>False Positives</div>
            <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#94a3b8', marginTop: '0.2rem' }}>
              {falsePositives}
            </div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Resolution Rate</div>
            <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#38bdf8', marginTop: '0.2rem' }}>
              {totalThreats > 0 ? Math.round((resolved / totalThreats) * 100) : 0}%
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: Category & Severity Breakdown */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.2rem' }}>
        
        {/* Category Breakdown */}
        <div className="soc-card">
          <h4 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0', marginBottom: '1rem' }}>
            Attack Category Breakdown
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
            {Object.keys(categoryDistribution).length > 0 ? (
              Object.entries(categoryDistribution).map(([cat, count]) => (
                <div key={cat} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: '1px solid #14203a' }}>
                  <span style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>{cat}</span>
                  <span className="badge badge-new">{count} incidents</span>
                </div>
              ))
            ) : (
              <p style={{ color: '#64748b', fontSize: '0.85rem' }}>No incident categories recorded.</p>
            )}
          </div>
        </div>

        {/* Severity Breakdown */}
        <div className="soc-card">
          <h4 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0', marginBottom: '1rem' }}>
            Severity & Risk Allocation
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: '1px solid #14203a' }}>
              <span style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>High Severity Threats (CVSS 7.0 - 10.0)</span>
              <span className="badge badge-high">{highSev} incidents</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: '1px solid #14203a' }}>
              <span style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>Medium Severity Threats (CVSS 4.0 - 6.9)</span>
              <span className="badge badge-medium">{medSev} incidents</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: '1px solid #14203a' }}>
              <span style={{ fontSize: '0.85rem', color: '#cbd5e1' }}>Low Severity / Informational</span>
              <span className="badge badge-low">{lowSev} incidents</span>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Suspicious Source IP Summary */}
      <div className="soc-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border-color)' }}>
          <h4 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
            Suspicious Source IP Address Audit
          </h4>
          <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
            Ranked list of originating IP addresses associated with detected security violations
          </p>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="soc-table">
            <thead>
              <tr>
                <th>Source IP</th>
                <th>Total Incident Count</th>
                <th>Recommended SOC Action</th>
              </tr>
            </thead>
            <tbody>
              {Object.keys(suspiciousIps).length > 0 ? (
                Object.entries(suspiciousIps).map(([ip, count]) => (
                  <tr key={ip}>
                    <td className="font-mono" style={{ color: '#38bdf8', fontWeight: 600 }}>{ip}</td>
                    <td style={{ fontWeight: 600 }}>{count}</td>
                    <td>
                      <span className="badge badge-high" style={{ fontSize: '0.7rem' }}>
                        Block at Perimeter Firewall (ACL Rule)
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="3" style={{ textAlign: 'center', padding: '2rem', color: '#64748b' }}>
                    No suspicious IP addresses on record.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
