import React, { useState, useEffect } from 'react';
import { 
  Sliders, 
  Save, 
  RotateCcw, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2,
  Clock,
  Cpu
} from 'lucide-react';

export default function SettingsPage({ 
  currentConfig, 
  onSaveConfig, 
  isSaving 
}) {
  const [formConfig, setFormConfig] = useState({
    bruteForceThreshold: 5,
    bruteForceWindowSec: 300,
    bruteForceSeverity: 'HIGH',
    portScanThreshold: 10,
    portScanWindowSec: 300,
    portScanSeverity: 'MEDIUM',
    unauthorizedThreshold: 5,
    unauthorizedWindowSec: 300,
    unauthorizedSeverity: 'HIGH',
    requestFloodThreshold: 50,
    requestFloodWindowSec: 60,
    requestFloodSeverity: 'HIGH'
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (currentConfig) {
      setFormConfig(currentConfig);
    }
  }, [currentConfig]);

  const handleChange = (field, value) => {
    setFormConfig(prev => ({
      ...prev,
      [field]: value
    }));
    setSavedSuccess(false);
  };

  const handleResetDefaults = () => {
    setFormConfig({
      bruteForceThreshold: 5,
      bruteForceWindowSec: 300,
      bruteForceSeverity: 'HIGH',
      portScanThreshold: 10,
      portScanWindowSec: 300,
      portScanSeverity: 'MEDIUM',
      unauthorizedThreshold: 5,
      unauthorizedWindowSec: 300,
      unauthorizedSeverity: 'HIGH',
      requestFloodThreshold: 50,
      requestFloodWindowSec: 60,
      requestFloodSeverity: 'HIGH'
    });
    setSavedSuccess(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSaveConfig(formConfig);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 4000);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.35rem', fontWeight: 700, color: '#f8fafc' }}>
            System Settings & Detection Thresholds
          </h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginTop: '0.2rem' }}>
            Configure detection parameters and time window sliding thresholds applied directly to the C++ ThreatDetector engine.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.6rem' }}>
          <button 
            type="button" 
            className="btn btn-secondary" 
            onClick={handleResetDefaults}
          >
            <RotateCcw size={15} /> Reset Academic Defaults
          </button>
          <button 
            type="button" 
            className="btn btn-primary" 
            onClick={handleSubmit}
            disabled={isSaving}
          >
            <Save size={15} /> {isSaving ? 'Updating Engine...' : 'Apply & Save to C++'}
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="soc-card" style={{ background: 'rgba(16, 185, 129, 0.1)', borderColor: '#10b981', display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
          <CheckCircle2 size={18} color="#10b981" />
          <span style={{ fontSize: '0.85rem', color: '#34d399', fontWeight: 500 }}>
            Detection thresholds successfully persisted to <span className="font-mono">detection_config.json</span>. Future C++ analyses will immediately apply these settings.
          </span>
        </div>
      )}

      {/* Configuration Grid */}
      <form onSubmit={handleSubmit} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1.2rem' }}>
        
        {/* Rule 1: Brute-Force Login Settings */}
        <div className="soc-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.8rem' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#f87171' }}>
              Rule 1: Brute-Force Login Detection
            </h3>
            <span className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>RULE_BRUTE_FORCE_01</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Failed Login Attempt Threshold:
              </label>
              <input 
                type="number" 
                min="1" 
                max="100" 
                className="soc-input" 
                style={{ width: '100%' }}
                value={formConfig.bruteForceThreshold}
                onChange={e => handleChange('bruteForceThreshold', parseInt(e.target.value) || 1)}
              />
              <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Default: 5 failed attempts</span>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Sliding Time Window (seconds):
              </label>
              <input 
                type="number" 
                min="10" 
                max="3600" 
                step="30"
                className="soc-input" 
                style={{ width: '100%' }}
                value={formConfig.bruteForceWindowSec}
                onChange={e => handleChange('bruteForceWindowSec', parseInt(e.target.value) || 60)}
              />
              <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Default: 300 seconds (5 minutes)</span>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Severity Assignment:
              </label>
              <select 
                className="soc-select" 
                style={{ width: '100%' }}
                value={formConfig.bruteForceSeverity}
                onChange={e => handleChange('bruteForceSeverity', e.target.value)}
              >
                <option value="HIGH">HIGH Severity</option>
                <option value="MEDIUM">MEDIUM Severity</option>
                <option value="LOW">LOW Severity</option>
              </select>
            </div>
          </div>
        </div>

        {/* Rule 2: Port Scanning Settings */}
        <div className="soc-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.8rem' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#fbbf24' }}>
              Rule 2: Port Scanning Detection
            </h3>
            <span className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>RULE_PORT_SCAN_02</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Distinct Destination Ports Threshold:
              </label>
              <input 
                type="number" 
                min="2" 
                max="500" 
                className="soc-input" 
                style={{ width: '100%' }}
                value={formConfig.portScanThreshold}
                onChange={e => handleChange('portScanThreshold', parseInt(e.target.value) || 2)}
              />
              <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Default: 10 distinct ports</span>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Sliding Time Window (seconds):
              </label>
              <input 
                type="number" 
                min="10" 
                max="3600" 
                step="30"
                className="soc-input" 
                style={{ width: '100%' }}
                value={formConfig.portScanWindowSec}
                onChange={e => handleChange('portScanWindowSec', parseInt(e.target.value) || 60)}
              />
              <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Default: 300 seconds (5 minutes)</span>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Severity Assignment:
              </label>
              <select 
                className="soc-select" 
                style={{ width: '100%' }}
                value={formConfig.portScanSeverity}
                onChange={e => handleChange('portScanSeverity', e.target.value)}
              >
                <option value="HIGH">HIGH Severity</option>
                <option value="MEDIUM">MEDIUM Severity</option>
                <option value="LOW">LOW Severity</option>
              </select>
            </div>
          </div>
        </div>

        {/* Rule 3: Unauthorized Resource Access */}
        <div className="soc-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.8rem' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#f472b6' }}>
              Rule 3: Unauthorized Resource Access
            </h3>
            <span className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>RULE_UNAUTH_ACCESS_03</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Denied / Restricted Requests Threshold:
              </label>
              <input 
                type="number" 
                min="1" 
                max="100" 
                className="soc-input" 
                style={{ width: '100%' }}
                value={formConfig.unauthorizedThreshold}
                onChange={e => handleChange('unauthorizedThreshold', parseInt(e.target.value) || 1)}
              />
              <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Default: 5 denied attempts</span>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Sliding Time Window (seconds):
              </label>
              <input 
                type="number" 
                min="10" 
                max="3600" 
                step="30"
                className="soc-input" 
                style={{ width: '100%' }}
                value={formConfig.unauthorizedWindowSec}
                onChange={e => handleChange('unauthorizedWindowSec', parseInt(e.target.value) || 60)}
              />
              <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Default: 300 seconds (5 minutes)</span>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Severity Assignment:
              </label>
              <select 
                className="soc-select" 
                style={{ width: '100%' }}
                value={formConfig.unauthorizedSeverity}
                onChange={e => handleChange('unauthorizedSeverity', e.target.value)}
              >
                <option value="HIGH">HIGH Severity</option>
                <option value="MEDIUM">MEDIUM Severity</option>
                <option value="LOW">LOW Severity</option>
              </select>
            </div>
          </div>
        </div>

        {/* Rule 4: Request Flooding */}
        <div className="soc-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.8rem' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#38bdf8' }}>
              Rule 4: Request Flooding (DoS)
            </h3>
            <span className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>RULE_REQUEST_FLOOD_04</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Request Rate Limit Threshold:
              </label>
              <input 
                type="number" 
                min="10" 
                max="2000" 
                step="5"
                className="soc-input" 
                style={{ width: '100%' }}
                value={formConfig.requestFloodThreshold}
                onChange={e => handleChange('requestFloodThreshold', parseInt(e.target.value) || 10)}
              />
              <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Default: 50 requests</span>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Sliding Time Window (seconds):
              </label>
              <input 
                type="number" 
                min="5" 
                max="600" 
                step="5"
                className="soc-input" 
                style={{ width: '100%' }}
                value={formConfig.requestFloodWindowSec}
                onChange={e => handleChange('requestFloodWindowSec', parseInt(e.target.value) || 10)}
              />
              <span style={{ fontSize: '0.7rem', color: '#64748b' }}>Default: 60 seconds (1 minute)</span>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', color: '#cbd5e1', marginBottom: '0.35rem' }}>
                Severity Assignment:
              </label>
              <select 
                className="soc-select" 
                style={{ width: '100%' }}
                value={formConfig.requestFloodSeverity}
                onChange={e => handleChange('requestFloodSeverity', e.target.value)}
              >
                <option value="HIGH">HIGH Severity</option>
                <option value="MEDIUM">MEDIUM Severity</option>
                <option value="LOW">LOW Severity</option>
              </select>
            </div>
          </div>
        </div>

      </form>

    </div>
  );
}
