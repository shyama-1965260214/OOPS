import React from 'react';
import { 
  ShieldAlert, 
  Flame, 
  AlertTriangle, 
  Play, 
  Info, 
  Terminal, 
  CheckCircle2,
  Cpu
} from 'lucide-react';

export default function ThreatDetectionPage({ 
  threats, 
  onRunAnalysis, 
  isLoading, 
  config 
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h2 style={{ fontSize: '1.35rem', fontWeight: 700, color: '#f8fafc' }}>
            Module 3: Cyberattack Detection Engine
          </h2>
          <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginTop: '0.2rem' }}>
            Rule-based temporal correlation and sliding window attack detection executed in C++.
          </p>
        </div>

        <button 
          className="btn btn-primary" 
          onClick={onRunAnalysis}
          disabled={isLoading}
          style={{ padding: '0.65rem 1.3rem' }}
        >
          <Play size={16} /> {isLoading ? 'Executing C++ Engine...' : 'Run Threat Analysis on Imported Logs'}
        </button>
      </div>

      {/* Academic Methodology Notice */}
      <div className="soc-card" style={{ background: 'rgba(56, 189, 248, 0.05)', borderColor: 'rgba(56, 189, 248, 0.25)', display: 'flex', gap: '0.8rem', alignItems: 'flex-start' }}>
        <Info size={20} color="#38bdf8" style={{ flexShrink: 0, marginTop: '0.1rem' }} />
        <div style={{ fontSize: '0.8rem', color: '#cbd5e1', lineHeight: '1.5' }}>
          <strong style={{ color: '#38bdf8' }}>Academic Note on Potential Threat Classification:</strong> Detections are formally designated as <em>Potential Threats</em>. In enterprise cybersecurity and SOC operations, rule-based log analysis identifies anomalous patterns meeting predefined security heuristics, which require security analyst triage to distinguish malicious actors from benign configuration errors or high-frequency automated services.
        </div>
      </div>

      {/* 4 Active Detection Heuristics Summary Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '1rem' }}>
        
        {/* Rule 1 */}
        <div className="soc-card" style={{ borderLeft: '4px solid #ef4444' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 600, color: '#f87171', fontSize: '0.85rem' }}>Attack 1: Brute-Force Login</span>
            <span className="badge badge-high">HIGH</span>
          </div>
          <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: '0.4rem 0' }}>
            Trigger: ≥ {config?.bruteForceThreshold || 5} failed logins within {((config?.bruteForceWindowSec || 300) / 60)} min window.
          </p>
          <span className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>Rule: RULE_BRUTE_FORCE_01</span>
        </div>

        {/* Rule 2 */}
        <div className="soc-card" style={{ borderLeft: '4px solid #f59e0b' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 600, color: '#fbbf24', fontSize: '0.85rem' }}>Attack 2: Port Scanning</span>
            <span className="badge badge-medium">MEDIUM</span>
          </div>
          <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: '0.4rem 0' }}>
            Trigger: ≥ {config?.portScanThreshold || 10} distinct ports probed within {((config?.portScanWindowSec || 300) / 60)} min window.
          </p>
          <span className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>Rule: RULE_PORT_SCAN_02</span>
        </div>

        {/* Rule 3 */}
        <div className="soc-card" style={{ borderLeft: '4px solid #ec4899' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 600, color: '#f472b6', fontSize: '0.85rem' }}>Attack 3: Unauthorized Access</span>
            <span className="badge badge-high">HIGH</span>
          </div>
          <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: '0.4rem 0' }}>
            Trigger: ≥ {config?.unauthorizedThreshold || 5} denied attempts within {((config?.unauthorizedWindowSec || 300) / 60)} min window.
          </p>
          <span className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>Rule: RULE_UNAUTH_ACCESS_03</span>
        </div>

        {/* Rule 4 */}
        <div className="soc-card" style={{ borderLeft: '4px solid #38bdf8' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 600, color: '#38bdf8', fontSize: '0.85rem' }}>Attack 4: Request Flooding</span>
            <span className="badge badge-high">HIGH</span>
          </div>
          <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: '0.4rem 0' }}>
            Trigger: ≥ {config?.requestFloodThreshold || 50} requests within {config?.requestFloodWindowSec || 60} sec window.
          </p>
          <span className="font-mono" style={{ fontSize: '0.7rem', color: '#64748b' }}>Rule: RULE_REQUEST_FLOOD_04</span>
        </div>
      </div>

      {/* Threats Table */}
      <div className="soc-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Detected Threats ({threats.length})
            </h3>
            <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
              Identified by C++ sliding window correlation algorithms
            </p>
          </div>
          <span className="badge badge-new" style={{ fontSize: '0.75rem' }}>
            <Cpu size={14} /> C++ Core Output
          </span>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="soc-table">
            <thead>
              <tr>
                <th>Threat ID</th>
                <th>Attack Category</th>
                <th>Source IP</th>
                <th>Timestamp</th>
                <th>Events in Window</th>
                <th>Severity</th>
                <th>Rule Triggered</th>
                <th>Detection Explanation</th>
              </tr>
            </thead>
            <tbody>
              {threats.length > 0 ? (
                threats.map(threat => (
                  <tr key={threat.threatId}>
                    <td className="font-mono" style={{ color: '#38bdf8', fontWeight: 600 }}>{threat.threatId}</td>
                    <td style={{ fontWeight: 600, color: '#f1f5f9' }}>{threat.attackCategory}</td>
                    <td className="font-mono" style={{ color: '#fbbf24' }}>{threat.sourceIp}</td>
                    <td className="font-mono" style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>{threat.timestamp}</td>
                    <td style={{ fontWeight: 700, color: '#f8fafc' }}>{threat.suspiciousEventCount}</td>
                    <td>
                      <span className={`badge ${threat.severity === 'HIGH' ? 'badge-high' : threat.severity === 'MEDIUM' ? 'badge-medium' : 'badge-low'}`}>
                        {threat.severity}
                      </span>
                    </td>
                    <td className="font-mono" style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                      {threat.ruleTriggered}
                    </td>
                    <td style={{ fontSize: '0.8rem', color: '#cbd5e1', maxWidth: '380px', lineHeight: '1.4' }}>
                      {threat.explanation}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '3rem 1rem', color: '#64748b' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.6rem' }}>
                      <CheckCircle2 size={36} color="#10b981" />
                      <span style={{ fontSize: '1rem', color: '#f1f5f9', fontWeight: 600 }}>Zero Threats Flagged</span>
                      <span style={{ fontSize: '0.8rem', maxWidth: '400px' }}>
                        No suspicious patterns detected in the current log file exceeding defined thresholds. If evaluating, load one of the attack simulation datasets.
                      </span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
