import React, { useState } from 'react';
import { 
  BarChart2, 
  Users, 
  CheckCircle, 
  XCircle, 
  AlertOctagon, 
  Filter, 
  Clock, 
  Network,
  Search
} from 'lucide-react';

export default function LogAnalysisPage({ analysisData }) {
  const [ipFilter, setIpFilter] = useState('');
  const [eventTypeFilter, setEventTypeFilter] = useState('ALL');

  const analysis = analysisData?.analysis || {};
  const totalEvents = analysis.totalEvents || 0;
  const successfulLogins = analysis.successfulLogins || 0;
  const failedLogins = analysis.failedLogins || 0;
  const otherEvents = analysis.otherEvents || 0;
  const uniqueIps = analysis.uniqueIps || 0;

  const eventDistribution = analysis.eventDistribution || {};
  const mostActiveIps = analysis.mostActiveIps || [];
  const repeatedFailures = analysis.repeatedFailures || {};
  const timeline = analysis.timeline || [];

  // Filter most active IPs
  const filteredIps = mostActiveIps.filter(item => {
    return item.ip.toLowerCase().includes(ipFilter.toLowerCase());
  });

  const maxEventCount = Math.max(...Object.values(eventDistribution), 1);
  const maxTimelineCount = Math.max(...timeline.map(t => t.count), 1);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      {/* Header */}
      <div>
        <h2 style={{ fontSize: '1.35rem', fontWeight: 700, color: '#f8fafc' }}>
          Module 2: Log Processing & Statistical Analysis
        </h2>
        <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginTop: '0.2rem' }}>
          Real-time pattern analysis, event distribution, IP activity clustering, and authentication audit computed by C++ LogAnalyzer.
        </p>
      </div>

      {/* 4 Metric Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '1.2rem' }}>
        
        {/* Total Events */}
        <div className="soc-card" style={{ borderTop: '3px solid #38bdf8' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#94a3b8', fontSize: '0.85rem' }}>
            <span>Total Log Entries</span>
            <BarChart2 size={18} color="#38bdf8" />
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#f8fafc', marginTop: '0.5rem' }}>
            {totalEvents.toLocaleString()}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.35rem' }}>
            Aggregated across all endpoints
          </div>
        </div>

        {/* Successful Logins */}
        <div className="soc-card" style={{ borderTop: '3px solid #10b981' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#94a3b8', fontSize: '0.85rem' }}>
            <span>Successful Logins</span>
            <CheckCircle size={18} color="#10b981" />
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#34d399', marginTop: '0.5rem' }}>
            {successfulLogins.toLocaleString()}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.35rem' }}>
            Valid authentication sessions
          </div>
        </div>

        {/* Failed Logins */}
        <div className="soc-card" style={{ borderTop: '3px solid #ef4444' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#94a3b8', fontSize: '0.85rem' }}>
            <span>Failed Logins</span>
            <XCircle size={18} color="#ef4444" />
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#f87171', marginTop: '0.5rem' }}>
            {failedLogins.toLocaleString()}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.35rem' }}>
            Potential credential stuffing / typos
          </div>
        </div>

        {/* Monitored IP Addresses */}
        <div className="soc-card" style={{ borderTop: '3px solid #8b5cf6' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: '#94a3b8', fontSize: '0.85rem' }}>
            <span>Monitored Unique IPs</span>
            <Users size={18} color="#8b5cf6" />
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#c4b5fd', marginTop: '0.5rem' }}>
            {uniqueIps}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.35rem' }}>
            Distinct network hosts tracked
          </div>
        </div>
      </div>

      {/* Row 2: Event Frequency & Repeated Failures */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))', gap: '1.2rem' }}>
        
        {/* Event Type Frequency Breakdown */}
        <div className="soc-card">
          <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0', marginBottom: '1rem' }}>
            Event Frequency Distribution
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
            {Object.keys(eventDistribution).length > 0 ? (
              Object.entries(eventDistribution).map(([event, count]) => {
                const pct = Math.round((count / maxEventCount) * 100);
                const isFailed = event.includes('FAILED') || event.includes('DENIED');
                return (
                  <div key={event}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: '0.3rem' }}>
                      <span className="font-mono" style={{ color: isFailed ? '#f87171' : '#cbd5e1' }}>{event}</span>
                      <span style={{ fontWeight: 600, color: isFailed ? '#f87171' : '#38bdf8' }}>{count}</span>
                    </div>
                    <div style={{ width: '100%', height: '7px', background: '#091021', borderRadius: '4px', overflow: 'hidden' }}>
                      <div style={{ 
                        width: `${Math.max(pct, 6)}%`, 
                        height: '100%', 
                        background: isFailed ? '#ef4444' : '#2563eb',
                        borderRadius: '4px' 
                      }} />
                    </div>
                  </div>
                );
              })
            ) : (
              <p style={{ color: '#64748b', fontSize: '0.85rem' }}>No event data available.</p>
            )}
          </div>
        </div>

        {/* Repeated Login Failures Alert Box */}
        <div className="soc-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.8rem' }}>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Repeated Login Failure Watchlist
            </h3>
            <span className="badge badge-high" style={{ fontSize: '0.7rem' }}>
              {Object.keys(repeatedFailures).length} IPs Flagged
            </span>
          </div>

          <p style={{ fontSize: '0.8rem', color: '#94a3b8', marginBottom: '1rem' }}>
            IPs with repeated authentication failures flagged by C++ analyzer for brute-force evaluation:
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem', maxHeight: '200px', overflowY: 'auto' }}>
            {Object.keys(repeatedFailures).length > 0 ? (
              Object.entries(repeatedFailures).map(([ip, count]) => (
                <div 
                  key={ip}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    background: '#091021',
                    padding: '0.6rem 0.8rem',
                    borderRadius: '6px',
                    borderLeft: count >= 5 ? '3px solid #ef4444' : '3px solid #f59e0b'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <Network size={16} color={count >= 5 ? '#ef4444' : '#f59e0b'} />
                    <span className="font-mono" style={{ color: '#f1f5f9', fontSize: '0.85rem' }}>{ip}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Failed Attempts:</span>
                    <span className="badge badge-high">{count}</span>
                  </div>
                </div>
              ))
            ) : (
              <div style={{ textAlign: 'center', padding: '1.5rem', color: '#64748b', fontSize: '0.85rem' }}>
                No repeated authentication failures detected.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Row 3: Activity Timeline Graph */}
      <div className="soc-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <div>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Activity Frequency Over Time Intervals
            </h3>
            <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
              Temporal distribution analyzed by C++ STL containers
            </p>
          </div>
          <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{timeline.length} Time Buckets</span>
        </div>

        {timeline.length > 0 ? (
          <div style={{ height: '140px', display: 'flex', alignItems: 'flex-end', gap: '6px', paddingTop: '1rem', paddingBottom: '1.2rem' }}>
            {timeline.map((bucket, i) => {
              const heightPct = Math.round((bucket.count / maxTimelineCount) * 100);
              return (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', height: '100%', justifyContent: 'flex-end' }}>
                  <div 
                    title={`${bucket.timeLabel}: ${bucket.count} events`}
                    style={{ 
                      width: '100%', 
                      height: `${Math.max(heightPct, 6)}%`, 
                      background: 'linear-gradient(180deg, #38bdf8 0%, #1e3a8a 100%)',
                      borderRadius: '3px 3px 0 0'
                    }} 
                  />
                  <span style={{ fontSize: '0.65rem', color: '#64748b', marginTop: '0.35rem', whiteSpace: 'nowrap' }}>
                    {bucket.timeLabel}
                  </span>
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '2rem', color: '#64748b', fontSize: '0.85rem' }}>
            No timeline data available.
          </div>
        )}
      </div>

      {/* Row 4: Most Active IP Addresses Table */}
      <div className="soc-card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ 
          padding: '1rem 1.25rem', 
          borderBottom: '1px solid var(--border-color)', 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: '0.8rem'
        }}>
          <div>
            <h3 style={{ fontSize: '0.95rem', fontWeight: 600, color: '#e2e8f0' }}>
              Most Active Source IP Addresses (Ranking)
            </h3>
            <p style={{ fontSize: '0.75rem', color: '#64748b' }}>
              Sorted descending by total event frequency
            </p>
          </div>

          <div style={{ position: 'relative' }}>
            <input 
              type="text" 
              className="soc-input" 
              placeholder="Filter by IP..." 
              value={ipFilter}
              onChange={e => setIpFilter(e.target.value)}
              style={{ paddingLeft: '2rem', width: '200px' }}
            />
            <Search size={14} style={{ position: 'absolute', left: '0.7rem', top: '50%', transform: 'translateY(-50%)', color: '#64748b' }} />
          </div>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="soc-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Source IP</th>
                <th>Total Events</th>
                <th>Failed Logins</th>
                <th>Successful Logins</th>
                <th>Distinct Ports</th>
                <th>Access Denied Count</th>
              </tr>
            </thead>
            <tbody>
              {filteredIps.length > 0 ? (
                filteredIps.map((act, index) => (
                  <tr key={act.ip}>
                    <td className="font-mono" style={{ color: '#64748b' }}>#{index + 1}</td>
                    <td className="font-mono" style={{ color: '#38bdf8', fontWeight: 600 }}>{act.ip}</td>
                    <td style={{ fontWeight: 600 }}>{act.totalEvents}</td>
                    <td>
                      <span style={{ color: act.failedLogins > 0 ? '#f87171' : '#94a3b8', fontWeight: act.failedLogins > 0 ? 600 : 400 }}>
                        {act.failedLogins}
                      </span>
                    </td>
                    <td>
                      <span style={{ color: act.successfulLogins > 0 ? '#34d399' : '#94a3b8' }}>
                        {act.successfulLogins}
                      </span>
                    </td>
                    <td className="font-mono">
                      <span style={{ color: act.uniquePorts >= 10 ? '#fbbf24' : '#cbd5e1', fontWeight: act.uniquePorts >= 10 ? 600 : 400 }}>
                        {act.uniquePorts}
                      </span>
                    </td>
                    <td>
                      <span style={{ color: act.deniedCount > 0 ? '#f87171' : '#94a3b8' }}>
                        {act.deniedCount}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '2rem', color: '#64748b' }}>
                    No IP activity records to display.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
