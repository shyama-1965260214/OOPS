import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  LayoutDashboard, 
  FileUp, 
  BarChart3, 
  ShieldAlert, 
  Bell, 
  FileSpreadsheet, 
  Sliders, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle,
  ExternalLink,
  Cpu
} from 'lucide-react';

import DashboardPage from './pages/DashboardPage';
import LogCollectionPage from './pages/LogCollectionPage';
import LogAnalysisPage from './pages/LogAnalysisPage';
import ThreatDetectionPage from './pages/ThreatDetectionPage';
import SecurityAlertsPage from './pages/SecurityAlertsPage';
import ReportsPage from './pages/ReportsPage';
import SettingsPage from './pages/SettingsPage';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [dashboardData, setDashboardData] = useState(null);
  const [samples, setSamples] = useState([]);
  const [config, setConfig] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState(null);

  const showNotification = (text, type = 'info') => {
    setNotification({ text, type });
    setTimeout(() => setNotification(null), 5000);
  };

  // 1. Initial Data Fetching
  const fetchDashboard = async () => {
    try {
      const res = await fetch('/api/dashboard');
      if (res.ok) {
        const data = await res.json();
        setDashboardData(data);
      }
    } catch (err) {
      console.error('Failed to fetch dashboard data:', err);
    }
  };

  const fetchSamples = async () => {
    try {
      const res = await fetch('/api/samples');
      if (res.ok) {
        const data = await res.json();
        setSamples(data);
      }
    } catch (err) {
      console.error('Failed to fetch sample datasets:', err);
    }
  };

  const fetchConfig = async () => {
    try {
      const res = await fetch('/api/config');
      if (res.ok) {
        const data = await res.json();
        setConfig(data.config);
      }
    } catch (err) {
      console.error('Failed to fetch config:', err);
    }
  };

  useEffect(() => {
    fetchDashboard();
    fetchSamples();
    fetchConfig();
  }, []);

  // 2. Trigger Threat Analysis on Active / Current File
  const handleRunAnalysis = async (customFilePath = null) => {
    setIsLoading(true);
    try {
      const activePath = customFilePath || dashboardData?.collection?.filePath || 'CyberShield/data/mixed_logs.csv';
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: activePath })
      });

      const result = await res.json();
      if (result.status === 'success') {
        showNotification(`C++ Engine completed analysis: ${result.threats?.length || 0} threats detected in ${result.collection?.validRecords || 0} valid logs.`, 'success');
        await fetchDashboard();
      } else {
        showNotification(result.message || 'Analysis error occurred', 'error');
      }
    } catch (err) {
      showNotification('Network communication error with backend bridge', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Load Sample Dataset
  const handleLoadSample = async (sampleId) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sampleName: sampleId })
      });

      const result = await res.json();
      if (result.status === 'success') {
        showNotification(`Loaded sample '${sampleId}' into C++ Engine. Processed ${result.collection?.validRecords} records.`, 'success');
        await fetchDashboard();
      } else {
        showNotification(result.message || 'Failed to load sample dataset', 'error');
      }
    } catch (err) {
      showNotification('Failed to communicate with backend server', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // 4. File Upload
  const handleFileUpload = async (file) => {
    setIsLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const uploadRes = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      });

      const uploadData = await uploadRes.json();
      if (uploadData.status === 'success') {
        showNotification(`File '${file.name}' uploaded. Executing C++ Engine analysis...`, 'info');
        await handleRunAnalysis(uploadData.filePath);
      } else {
        showNotification(uploadData.message || 'File upload failed', 'error');
      }
    } catch (err) {
      showNotification('Error during file upload', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // 5. Update Alert Status (Persistence)
  const handleUpdateStatus = async (alertId, newStatus) => {
    try {
      const res = await fetch(`/api/alerts/${alertId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });

      const data = await res.json();
      if (data.status === 'success') {
        showNotification(`Alert ${alertId} status updated to '${newStatus}' and persisted to disk.`, 'success');
        await fetchDashboard();
      } else {
        showNotification(data.message || 'Failed to update alert status', 'error');
      }
    } catch (err) {
      showNotification('Error communicating alert update to backend', 'error');
    }
  };

  // 6. Download Report
  const handleDownloadReport = () => {
    window.location.href = '/api/report/download';
    showNotification('Downloading generated SOC security CSV report...', 'info');
  };

  // 7. Save Config
  const handleSaveConfig = async (newConfig) => {
    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newConfig)
      });

      const data = await res.json();
      if (data.status === 'success') {
        setConfig(data.config);
        showNotification('Detection configuration saved to disk and applied to C++ engine.', 'success');
      } else {
        showNotification(data.message || 'Failed to update configuration', 'error');
      }
    } catch (err) {
      showNotification('Error saving configuration', 'error');
    }
  };

  const threatCount = dashboardData?.threats?.length || 0;
  const alertCount = dashboardData?.alerts?.length || 0;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'collection', label: 'Log Collection', icon: FileUp },
    { id: 'analysis', label: 'Log Analysis', icon: BarChart3 },
    { id: 'detection', label: 'Threat Detection', icon: ShieldAlert, badge: threatCount > 0 ? threatCount : null, badgeColor: '#ef4444' },
    { id: 'alerts', label: 'Security Alerts', icon: Bell, badge: alertCount > 0 ? alertCount : null, badgeColor: '#38bdf8' },
    { id: 'reports', label: 'Reports', icon: FileSpreadsheet },
    { id: 'settings', label: 'Settings', icon: Sliders },
  ];

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg-primary)' }}>
      
      {/* Sidebar Navigation */}
      <aside style={{
        width: '260px',
        background: 'var(--bg-secondary)',
        borderRight: '1px solid var(--border-color)',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        position: 'sticky',
        top: 0,
        height: '100vh',
        zIndex: 50
      }}>
        {/* Brand */}
        <div>
          <div style={{ padding: '1.5rem 1.25rem', borderBottom: '1px solid var(--border-color)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <div style={{ 
                background: 'linear-gradient(135deg, #1d4ed8 0%, #38bdf8 100%)', 
                padding: '0.55rem', 
                borderRadius: '8px',
                display: 'flex',
                boxShadow: '0 0 16px rgba(56, 189, 248, 0.4)'
              }}>
                <Shield size={24} color="#ffffff" />
              </div>
              <div>
                <h1 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#f8fafc', letterSpacing: '0.04em' }}>
                  CYBERSHIELD
                </h1>
                <p style={{ fontSize: '0.65rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  C++ SOC Analysis System
                </p>
              </div>
            </div>
          </div>

          {/* Nav Items */}
          <nav style={{ padding: '1rem 0.75rem', display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    width: '100%',
                    padding: '0.65rem 0.9rem',
                    borderRadius: '7px',
                    fontSize: '0.85rem',
                    fontWeight: isActive ? 600 : 500,
                    color: isActive ? '#f8fafc' : '#94a3b8',
                    background: isActive ? '#162444' : 'transparent',
                    border: isActive ? '1px solid #2a3e68' : '1px solid transparent',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                    textAlign: 'left'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.7rem' }}>
                    <Icon size={18} color={isActive ? '#38bdf8' : '#64748b'} />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span style={{ 
                      background: item.badgeColor, 
                      color: '#ffffff', 
                      fontSize: '0.7rem', 
                      fontWeight: 700, 
                      padding: '0.15rem 0.45rem', 
                      borderRadius: '999px' 
                    }}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer info in sidebar */}
        <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid var(--border-color)', fontSize: '0.75rem', color: '#64748b' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.3rem' }}>
            <span className="pulse-beacon"></span>
            <span style={{ color: '#34d399', fontWeight: 600 }}>C++ Engine v1.0.0</span>
          </div>
          <div>C++17 STL &bull; Real Log Logic</div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        
        {/* Top Header Bar */}
        <header style={{
          height: '64px',
          background: 'var(--bg-secondary)',
          borderBottom: '1px solid var(--border-color)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 2rem',
          position: 'sticky',
          top: 0,
          zIndex: 40
        }}>
          <div>
            <span style={{ fontSize: '0.85rem', fontWeight: 600, color: '#f8fafc' }}>
              {navItems.find(n => n.id === activeTab)?.label}
            </span>
            <span style={{ fontSize: '0.75rem', color: '#64748b', marginLeft: '0.75rem' }}>
              Intelligent Rule-Based Security Monitoring and Incident Analysis
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <button 
              className="btn btn-secondary" 
              onClick={fetchDashboard}
              disabled={isLoading}
              style={{ fontSize: '0.8rem', padding: '0.4rem 0.8rem' }}
              title="Refresh all metrics from engine"
            >
              <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} /> Refresh
            </button>
            <div style={{ fontSize: '0.8rem', color: '#94a3b8', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Cpu size={15} color="#38bdf8" />
              <span>Native C++ Binary Backend</span>
            </div>
          </div>
        </header>

        {/* Notification Toast */}
        {notification && (
          <div style={{
            position: 'fixed',
            top: '74px',
            right: '24px',
            zIndex: 9999,
            background: notification.type === 'error' ? 'rgba(239, 68, 68, 0.95)' : 
                        notification.type === 'success' ? 'rgba(16, 185, 129, 0.95)' : 'rgba(56, 189, 248, 0.95)',
            color: '#ffffff',
            padding: '0.8rem 1.25rem',
            borderRadius: '8px',
            boxShadow: '0 10px 25px rgba(0,0,0,0.5)',
            fontSize: '0.85rem',
            fontWeight: 500,
            display: 'flex',
            alignItems: 'center',
            gap: '0.6rem',
            maxWidth: '450px'
          }}>
            {notification.type === 'error' ? <AlertCircle size={18} /> : <CheckCircle2 size={18} />}
            <span>{notification.text}</span>
          </div>
        )}

        {/* Page Container */}
        <main style={{ padding: '2rem', flex: 1 }}>
          {activeTab === 'dashboard' && (
            <DashboardPage 
              dashboardData={dashboardData}
              onNavigate={setActiveTab}
              onRunAnalysis={() => handleRunAnalysis()}
              onDownloadReport={handleDownloadReport}
              isLoading={isLoading}
            />
          )}

          {activeTab === 'collection' && (
            <LogCollectionPage 
              collectionData={dashboardData?.collection}
              samples={samples}
              onLoadSample={handleLoadSample}
              onFileUpload={handleFileUpload}
              isLoading={isLoading}
            />
          )}

          {activeTab === 'analysis' && (
            <LogAnalysisPage 
              analysisData={dashboardData}
            />
          )}

          {activeTab === 'detection' && (
            <ThreatDetectionPage 
              threats={dashboardData?.threats || []}
              onRunAnalysis={() => handleRunAnalysis()}
              isLoading={isLoading}
              config={config}
            />
          )}

          {activeTab === 'alerts' && (
            <SecurityAlertsPage 
              alerts={dashboardData?.alerts || []}
              onUpdateStatus={handleUpdateStatus}
              onRefreshAlerts={fetchDashboard}
              isUpdating={isLoading}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsPage 
              summary={dashboardData?.summary}
              analysis={dashboardData?.analysis}
              onDownloadReport={handleDownloadReport}
              isDownloading={isLoading}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsPage 
              currentConfig={config}
              onSaveConfig={handleSaveConfig}
              isSaving={isLoading}
            />
          )}
        </main>
      </div>

    </div>
  );
}
