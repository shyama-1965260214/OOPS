@echo off
echo ========================================================
echo   CYBERSHIELD: Starting React + Vite SOC Dashboard
echo ========================================================

set "PATH=C:\Users\Administrator\AppData\Local\Programs\nodejs\node-v20.18.0-win-x64;%PATH%"
cd /d "%~dp0\frontend"

echo [*] Starting Vite Dev Server on http://localhost:5173...
npm run dev
pause
