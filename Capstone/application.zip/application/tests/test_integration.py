import json
import sys
import os

# Import the actual Flask app directly
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backend"))
from app import app, ALERTS_STORE, DATA_DIR

client = app.test_client()

print("========================================================")
print("   CYBERSHIELD BACKEND & C++ END-TO-END INTEGRATION TEST")
print("========================================================")

# 1. Health check
res = client.get("/api/health")
health = json.loads(res.data)
print(f"[TEST 1] Health status: {health['status']} | C++ Engine Ready: {health['engine_executable']}")
assert health['status'] == 'healthy'
assert health['engine_executable'] is True

# 2. Samples check
res = client.get("/api/samples")
samples = json.loads(res.data)
print(f"[TEST 2] Available sample datasets: {len(samples)}")
assert len(samples) == 6

# 3. Analyze mixed_logs.csv through C++ Engine
print("[TEST 3] Triggering C++ Engine analysis on 'mixed_logs.csv'...")
res = client.post("/api/analyze", json={"sampleName": "mixed_logs.csv"})
data = json.loads(res.data)
print(f"         Status: {data['status']}")
print(f"         Total records collected: {data['collection']['totalLines']}")
print(f"         Valid records processed: {data['collection']['validRecords']}")
print(f"         Invalid records rejected: {data['collection']['invalidRecords']}")
print(f"         Threats flagged by C++: {len(data['threats'])}")
assert data['status'] == 'success'
assert data['collection']['validRecords'] > 200
assert data['collection']['invalidRecords'] == 2
assert len(data['threats']) == 4

# 4. Verify Dashboard Metrics API
res = client.get("/api/dashboard")
dash = json.loads(res.data)
print(f"[TEST 4] Dashboard summary alerts count: {dash['summary']['totalAlerts']}")
assert dash['summary']['totalAlerts'] >= 4

# 5. Alert status update (Analyst Triage)
alert_id = data['alerts'][0]['alertId']
print(f"[TEST 5] Updating alert status for '{alert_id}' to 'Investigating'...")
res = client.post(f"/api/alerts/{alert_id}/status", json={"status": "Investigating"})
up_data = json.loads(res.data)
print(f"         Response status: {up_data['status']} | New Status: {up_data['newStatus']}")
assert up_data['status'] == 'success'
assert up_data['newStatus'] == 'Investigating'

# 6. Verify persistence from storage file
res = client.get("/api/alerts")
alerts_data = json.loads(res.data)
target = next(a for a in alerts_data['alerts'] if a['alertId'] == alert_id)
print(f"[TEST 6] Persistence verification: Alert '{target['alertId']}' persisted status: '{target['status']}'")
assert target['status'] == 'Investigating'

# 7. Update status to 'Resolved' and re-verify
res = client.post(f"/api/alerts/{alert_id}/status", json={"status": "Resolved"})
res = client.get("/api/alerts")
alerts_data = json.loads(res.data)
target = next(a for a in alerts_data['alerts'] if a['alertId'] == alert_id)
print(f"         Further transition: Alert '{target['alertId']}' status is now: '{target['status']}'")
assert target['status'] == 'Resolved'

# 8. Test CSV report generation
print("[TEST 8] Testing SOC CSV report generation from persistent store...")
res = client.get("/api/report/download")
csv_text = res.data.decode("utf-8")
print(f"         CSV Report generated successfully ({len(csv_text)} bytes).")
assert "CYBERSHIELD SECURITY INCIDENT & ANALYSIS REPORT" in csv_text
assert "Brute-Force Login" in csv_text
assert "Port Scanning" in csv_text
assert "Resolved Incidents" in csv_text

print("\n========================================================")
print("   ALL INTEGRATION & PERSISTENCE TESTS PASSED 100%   ")
print("========================================================")
