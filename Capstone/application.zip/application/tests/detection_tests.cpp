#include "../cpp_engine/LogRecord.h"
#include "../cpp_engine/LogCollector.h"
#include "../cpp_engine/LogAnalyzer.h"
#include "../cpp_engine/ThreatDetector.h"
#include "../cpp_engine/AlertManager.h"

#include <iostream>
#include <cassert>
#include <vector>
#include <fstream>
#include <cstdio>

// Helper to write a temporary log file for testing
static void writeTempFile(const std::string& path, const std::string& content) {
    std::ofstream out(path);
    out << content;
    out.close();
}

int runStandaloneTests() {
    std::cout << "========================================================\n";
    std::cout << "   CYBERSHIELD STANDALONE C++ CORE VERIFICATION SUITE   \n";
    std::cout << "   Academic Capstone Verification & Security Rule Tests \n";
    std::cout << "========================================================\n\n";

    int passedTests = 0;
    int totalTests = 8;

    // ---------------------------------------------------------
    // TEST 1: LogCollector & Validation
    // ---------------------------------------------------------
    std::cout << "[TEST 1/8] Verifying LogCollector parser and validation logic...";
    {
        std::string testCsv = "test_collector.csv";
        std::string content = 
            "timestamp,source_ip,username,event_type,destination_port,status\n"
            "2026-10-30 09:00:00,192.168.1.10,admin,LOGIN_SUCCESS,22,SUCCESS\n"
            "malformed-timestamp,192.168.1.10,admin,LOGIN_FAILED,22,FAILED\n" // Bad timestamp
            "2026-10-30 09:01:00,999.999.1.10,admin,LOGIN_FAILED,22,FAILED\n"   // Bad IP
            "2026-10-30 09:02:00,192.168.1.15,user1,LOGIN_FAILED,,FAILED\n"    // Valid optional port
            "2026-10-30 09:03:00,192.168.1.20,user2,FILE_ACCESS,445,SUCCESS\n"; // Valid

        writeTempFile(testCsv, content);

        LogCollector collector;
        bool loaded = collector.loadFromFile(testCsv);
        assert(loaded == true);
        assert(collector.getValidCount() == 3);
        assert(collector.getInvalidCount() == 2);

        std::remove(testCsv.c_str());
        std::cout << " [PASSED]\n";
        passedTests++;
    }

    // ---------------------------------------------------------
    // TEST 2: LogAnalyzer Aggregations
    // ---------------------------------------------------------
    std::cout << "[TEST 2/8] Verifying LogAnalyzer metrics & event distribution...";
    {
        std::vector<LogRecord> recs;
        int64_t baseTime = 1761814800; // arbitrary epoch
        // 2 successful logins, 3 failed logins, 1 access denied
        recs.push_back({1, "2026-10-30 09:00:00", baseTime, "192.168.1.10", "admin", "LOGIN_SUCCESS", 22, "SUCCESS", true, ""});
        recs.push_back({2, "2026-10-30 09:01:00", baseTime + 60, "192.168.1.10", "admin", "LOGIN_SUCCESS", 22, "SUCCESS", true, ""});
        recs.push_back({3, "2026-10-30 09:02:00", baseTime + 120, "192.168.1.50", "root", "LOGIN_FAILED", 22, "FAILED", true, ""});
        recs.push_back({4, "2026-10-30 09:03:00", baseTime + 180, "192.168.1.50", "root", "LOGIN_FAILED", 22, "FAILED", true, ""});
        recs.push_back({5, "2026-10-30 09:04:00", baseTime + 240, "192.168.1.50", "root", "LOGIN_FAILED", 22, "FAILED", true, ""});
        recs.push_back({6, "2026-10-30 09:05:00", baseTime + 300, "192.168.1.99", "guest", "ACCESS_DENIED", 80, "DENIED", true, ""});

        LogAnalyzer analyzer;
        analyzer.analyze(recs);
        const auto& m = analyzer.getMetrics();

        assert(m.totalEvents == 6);
        assert(m.successfulLogins == 2);
        assert(m.failedLogins == 3);
        assert(m.uniqueIpCount == 3);
        assert(m.repeatedLoginFailures.at("192.168.1.50") == 3);
        assert(m.mostActiveIps[0].ip == "192.168.1.50");

        std::cout << " [PASSED]\n";
        passedTests++;
    }

    // ---------------------------------------------------------
    // TEST 3: Threat Detection - Attack 1: Brute-Force Login
    // ---------------------------------------------------------
    std::cout << "[TEST 3/8] Verifying Attack 1: Brute-Force Login Detection (>= 5 failed in 5 min)...";
    {
        ThreatDetector detector;
        std::vector<LogRecord> recs;
        int64_t baseTime = 1761814800;

        // 6 failed logins within 180 seconds (3 min) from 10.0.0.5 -> should trigger HIGH alert
        for (int i = 0; i < 6; ++i) {
            recs.push_back({i + 1, "2026-10-30 09:0" + std::to_string(i) + ":00", baseTime + (i * 30), 
                            "10.0.0.5", "admin", "LOGIN_FAILED", 22, "FAILED", true, ""});
        }

        // 3 failed logins from 10.0.0.6 -> below threshold, should NOT trigger
        for (int i = 0; i < 3; ++i) {
            recs.push_back({i + 7, "2026-10-30 09:0" + std::to_string(i) + ":00", baseTime + (i * 30), 
                            "10.0.0.6", "admin", "LOGIN_FAILED", 22, "FAILED", true, ""});
        }

        auto threats = detector.detectThreats(recs);
        assert(threats.size() == 1);
        assert(threats[0].attackCategory == "Brute-Force Login");
        assert(threats[0].sourceIp == "10.0.0.5");
        assert(threats[0].severity == "HIGH");
        assert(threats[0].suspiciousEventCount == 6);

        std::cout << " [PASSED]\n";
        passedTests++;
    }

    // ---------------------------------------------------------
    // TEST 4: Threat Detection - Attack 2: Port Scanning
    // ---------------------------------------------------------
    std::cout << "[TEST 4/8] Verifying Attack 2: Port Scanning Detection (>= 10 distinct ports in 5 min)...";
    {
        ThreatDetector detector;
        std::vector<LogRecord> recs;
        int64_t baseTime = 1761814800;

        // Probing 12 distinct ports within 120s from 10.0.0.88 -> should trigger MEDIUM alert
        for (int p = 1; p <= 12; ++p) {
            recs.push_back({p, "2026-10-30 09:0" + std::to_string(p % 5) + ":00", baseTime + (p * 10), 
                            "10.0.0.88", "", "PORT_SCAN", 1000 + p, "CLOSED", true, ""});
        }

        // Probing only 4 ports from 10.0.0.99 -> below threshold, should NOT trigger
        for (int p = 1; p <= 4; ++p) {
            recs.push_back({p + 20, "2026-10-30 09:01:00", baseTime + (p * 10), 
                            "10.0.0.99", "", "PORT_SCAN", 8000 + p, "CLOSED", true, ""});
        }

        auto threats = detector.detectThreats(recs);
        assert(threats.size() == 1);
        assert(threats[0].attackCategory == "Port Scanning");
        assert(threats[0].sourceIp == "10.0.0.88");
        assert(threats[0].severity == "MEDIUM");
        assert(threats[0].suspiciousEventCount == 12);

        std::cout << " [PASSED]\n";
        passedTests++;
    }

    // ---------------------------------------------------------
    // TEST 5: Threat Detection - Attack 3: Unauthorized Resource Access
    // ---------------------------------------------------------
    std::cout << "[TEST 5/8] Verifying Attack 3: Unauthorized Resource Access (>= 5 denied in 5 min)...";
    {
        ThreatDetector detector;
        std::vector<LogRecord> recs;
        int64_t baseTime = 1761814800;

        // 5 denied attempts within 200s from 10.0.0.77 -> should trigger HIGH alert
        for (int i = 0; i < 5; ++i) {
            recs.push_back({i + 1, "2026-10-30 09:0" + std::to_string(i) + ":00", baseTime + (i * 40), 
                            "10.0.0.77", "intruder", "ACCESS_DENIED", 443, "DENIED", true, ""});
        }

        // 2 denied attempts from 10.0.0.12 -> below threshold
        for (int i = 0; i < 2; ++i) {
            recs.push_back({i + 10, "2026-10-30 09:01:00", baseTime + (i * 40), 
                            "10.0.0.12", "user", "ACCESS_DENIED", 443, "DENIED", true, ""});
        }

        auto threats = detector.detectThreats(recs);
        assert(threats.size() == 1);
        assert(threats[0].attackCategory == "Unauthorized Resource Access");
        assert(threats[0].sourceIp == "10.0.0.77");
        assert(threats[0].severity == "HIGH");
        assert(threats[0].suspiciousEventCount == 5);

        std::cout << " [PASSED]\n";
        passedTests++;
    }

    // ---------------------------------------------------------
    // TEST 6: Threat Detection - Attack 4: Request Flooding
    // ---------------------------------------------------------
    std::cout << "[TEST 6/8] Verifying Attack 4: Request Flooding (>= 50 requests in 1 min)...";
    {
        ThreatDetector detector;
        std::vector<LogRecord> recs;
        int64_t baseTime = 1761814800;

        // 55 requests in 45 seconds from 10.0.0.222 -> should trigger HIGH alert
        for (int i = 0; i < 55; ++i) {
            recs.push_back({i + 1, "2026-10-30 09:00:" + std::to_string(i % 60), baseTime + (i % 45), 
                            "10.0.0.222", "client", "HTTP_REQUEST", 80, "SUCCESS", true, ""});
        }

        // 20 requests from 10.0.0.223 -> below threshold
        for (int i = 0; i < 20; ++i) {
            recs.push_back({i + 100, "2026-10-30 09:00:" + std::to_string(i % 60), baseTime + (i % 45), 
                            "10.0.0.223", "client", "HTTP_REQUEST", 80, "SUCCESS", true, ""});
        }

        auto threats = detector.detectThreats(recs);
        assert(threats.size() == 1);
        assert(threats[0].attackCategory == "Request Flooding");
        assert(threats[0].sourceIp == "10.0.0.222");
        assert(threats[0].severity == "HIGH");
        assert(threats[0].suspiciousEventCount == 55);

        std::cout << " [PASSED]\n";
        passedTests++;
    }

    // ---------------------------------------------------------
    // TEST 7: Normal Activity Baseline (Negative Control)
    // ---------------------------------------------------------
    std::cout << "[TEST 7/8] Verifying Normal Activity Baseline (No False Positives)...";
    {
        ThreatDetector detector;
        std::vector<LogRecord> recs;
        int64_t baseTime = 1761814800;

        // 120 normal user operations spread across 30 minutes: logins, page views, file downloads
        for (int i = 0; i < 120; ++i) {
            std::string ip = "192.168.1." + std::to_string(10 + (i % 5));
            int64_t t = baseTime + (i * 15); // spaced every 15 seconds
            std::string ev = (i % 10 == 0) ? "LOGIN_SUCCESS" : "PAGE_VIEW";
            recs.push_back({i + 1, "2026-10-30 09:00:00", t, ip, "employee", ev, 443, "SUCCESS", true, ""});
        }

        auto threats = detector.detectThreats(recs);
        assert(threats.empty()); // ZERO threats flagged!

        std::cout << " [PASSED]\n";
        passedTests++;
    }

    // ---------------------------------------------------------
    // TEST 8: AlertManager Lifecycle & Persistence
    // ---------------------------------------------------------
    std::cout << "[TEST 8/8] Verifying AlertManager persistence & status transitions...";
    {
        std::string storePath = "test_alerts_store.json";
        std::remove(storePath.c_str());

        AlertManager am(storePath);

        std::vector<DetectedThreat> threats;
        threats.push_back({"THR-1", "Brute-Force Login", "192.168.1.100", "2026-10-30 09:05:00", 
                           1761815100, 6, "HIGH", "Simulated threat", "RULE_01", "5 min window"});
        am.ingestThreats(threats);

        assert(am.getAllAlerts().size() == 1);
        std::string alertId = am.getAllAlerts()[0].alertId;
        assert(am.getAllAlerts()[0].status == "New");

        // Transition: New -> Investigating
        bool up1 = am.updateStatus(alertId, "Investigating");
        assert(up1 == true);
        assert(am.getAllAlerts()[0].status == "Investigating");

        // Transition: Investigating -> Resolved
        bool up2 = am.updateStatus(alertId, "Resolved");
        assert(up2 == true);
        assert(am.getAllAlerts()[0].status == "Resolved");

        // Reload from disk to verify persistence across restarts
        AlertManager amReloaded(storePath);
        assert(amReloaded.getAllAlerts().size() == 1);
        assert(amReloaded.getAllAlerts()[0].alertId == alertId);
        assert(amReloaded.getAllAlerts()[0].status == "Resolved"); // Persisted!

        std::remove(storePath.c_str());
        std::cout << " [PASSED]\n";
        passedTests++;
    }

    std::cout << "\n========================================================\n";
    std::cout << "   TEST RESULTS: " << passedTests << " / " << totalTests << " TESTS PASSED (100% SUCCESS)\n";
    std::cout << "   All C++ detection algorithms verified successfully.\n";
    std::cout << "========================================================\n";

    return 0;
}

#ifndef EXCLUDE_STANDALONE_MAIN
int main() {
    return runStandaloneTests();
}
#endif
