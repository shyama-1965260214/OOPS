@echo off
title CyberShield - Startup
color 0B

echo.
echo  ==========================================================
echo    CYBERSHIELD - Cyberattack Detection System
echo  ==========================================================
echo.

REM ── Set all required tool paths ────────────────────────────
set "PATH=C:\msys64\ucrt64\bin;C:\Users\Administrator\AppData\Local\Programs\Python\Python313;C:\Users\Administrator\AppData\Local\Programs\Python\Python313\Scripts;C:\Users\Administrator\AppData\Local\Programs\nodejs\node-v20.18.0-win-x64;%PATH%"

REM ── Kill anything already using port 5000 or 5173 ──────────
echo [*] Clearing any old processes on ports 5000 and 5173...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":5000 " 2^>nul') do (
    taskkill /PID %%a /F >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":5173 " 2^>nul') do (
    taskkill /PID %%a /F >nul 2>&1
)
timeout /t 1 /nobreak >nul
echo     Done.
echo.

REM ── Start Flask Backend ─────────────────────────────────────
echo [1/2] Starting Flask Backend on http://localhost:5000 ...
start "CyberShield - Flask Backend" cmd /k "color 0A && title CyberShield Flask Backend && echo. && echo  [BACKEND RUNNING] Keep this window open! && echo. && cd /d %~dp0 && C:\Users\Administrator\AppData\Local\Programs\Python\Python313\python.exe backend\app.py"
echo     Waiting for backend to start...
timeout /t 4 /nobreak >nul

REM ── Start React Frontend ────────────────────────────────────
echo [2/2] Starting React Frontend on http://localhost:5173 ...
start "CyberShield - React Frontend" cmd /k "color 0E && title CyberShield React Frontend && echo. && echo  [FRONTEND RUNNING] Keep this window open! && echo. && cd /d %~dp0\frontend && C:\Users\Administrator\AppData\Local\Programs\nodejs\node-v20.18.0-win-x64\npm.cmd run dev -- --port 5173"
echo     Waiting for frontend to start...
timeout /t 5 /nobreak >nul

REM ── Open browser ────────────────────────────────────────────
echo [*] Opening dashboard in browser...
start "" "http://localhost:5173"

echo.
echo  ==========================================================
echo    CYBERSHIELD IS LIVE
echo    Dashboard  :  http://localhost:5173
echo    Backend API:  http://localhost:5000/api/health
echo  ==========================================================
echo.
echo    IMPORTANT: Keep both Flask and React windows open.
echo    Closing them will stop the application.
echo.
echo    To stop: Close the Flask and React terminal windows.
echo.
pause
