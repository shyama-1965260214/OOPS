@echo off
echo ========================================================
echo   CYBERSHIELD: Starting Local API Bridge (Flask)
echo ========================================================

set "PATH=C:\msys64\ucrt64\bin;C:\Users\Administrator\AppData\Local\Programs\Python\Python313;C:\Users\Administrator\AppData\Local\Programs\Python\Python313\Scripts;%PATH%"
cd /d "%~dp0\backend"

echo [*] Starting CyberShield Bridge on http://localhost:5000...
python app.py
pause
